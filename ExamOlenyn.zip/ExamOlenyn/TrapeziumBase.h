#pragma once
#ifndef _TrapeziumBase_H_
#define _TrapeziumBase_H_

#include <iostream>
#include "Point.h"
#include "Segment.h"
#include "Trapezium.h"
#include "TrapeziumAxes.h"
using namespace  std;

class Segment;
class TrapeziumAxes;
class TrapeziumBase 
	:  public Trapezium
{
public:
	class Segment
	{
	private:
		const Point& _a;

		const Point& _b;

		static int _freeID;
		int _myId;

		Segment(const Segment&);

		Segment& operator=(const Segment&);

	public:

		Segment(const Point& start, const Point& end);

		~Segment();

		const Point& start() const { return _a; };
		const Point& end() const { return _b; };

		double length() const;

		double distance(const Point&) const;

		int getID() const { return _myId; };
	};
	class BadTrapeziumBase {

	private:
		const string _reason;
	public:
		explicit BadTrapeziumBase(string r = "=") : _reason(std::move(r)) {};
		~BadTrapeziumBase() {};

		void diagnose() const {
			cerr << _reason << endl;
		}
	};
	typedef Segment* TrapeziumBase::* SidePtr;

	TrapeziumBase(const ::Segment& a=0, const ::Segment& b=0);
	TrapeziumBase(const TrapeziumBase&);
	TrapeziumBase(const TrapeziumAxes&);
	~TrapeziumBase() {};

	TrapeziumBase& operator=(const TrapeziumBase&);

	const Point& a11() const { return _a11; };
	const Point& a12() const { return _a12; };
	const Point& a21() const { return _a21; };
	const Point& a22() const { return _a22; };
	 Point& a11()  { return _a11; };
	 Point& a12()  { return _a12; };
	 Point& a21()  { return _a21; };
	 Point& a22()  { return _a22; };

	 void cheakParalelnist();

	
	 const Segment& A11_A12_side() const;
	 const Segment& A11_A21_side() const;
	 const Segment& A21_A22_side() const;
	 const Segment& A22_A12_side() const;

	 double perumetr() const {
		 return A11_A12_side().length() + A11_A21_side().length() + A21_A22_side().length() + A22_A12_side().length();
	 };

	 void vidobrazenya(char k);

	 void povorot(double angle);
	double area() const;

	
	const ::Segment& mediana() const;

	

	

private:
	Point _a11, _a12, _a21, _a22;

	mutable Segment* _A11_A12_side, * _A21_A22_side, * _A11_A21_side, * _A22_A12_side;
};
ostream& operator<<(ostream&, const TrapeziumBase::Segment&);
ostream& operator<<(ostream&, const TrapeziumBase&);

#endif