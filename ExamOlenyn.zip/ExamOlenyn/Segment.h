﻿
#ifndef _SEGMENT_H_
#define _SEGMENT_H_


#include <iostream>
#include "Point.h"
using namespace std;




class Segment

{

private:

	// Çàñîáè îáë³êóâàííÿ â³äð³çê³â

	static int _freeID;

	const int _myId;

	// Òî÷êà ïî÷àòêó â³äð³çêó

	Point _a;

	// Òî÷êà ê³íöÿ â³äð³çêó

	Point _b;

public:


	Segment& vidobrazenya(char k);

	Segment& povorot(double angle);



	// Êîíñòðóêòîðè â³äð³çê³â

	// 1) çà êîîðäèíàòàìè éîãî ê³íö³â

	Segment(const double x1 = 0, const double y1 = 0,

		const double x2 = 1, const double y2 = 0);

	// 2) çà òî÷êàìè ïî÷àòêó ³ ê³íöÿ

	Segment(const Point& start, const Point& end);

	// 3) êîï³þâàëüíèé êîíñòðóêòîð

	Segment(const Segment&);

	// Äåñòðóêòîð

	~Segment();

	// Ïðèñâîºííÿ

	Segment& operator=(const Segment&);

	// Ñåëåêòîðè  òî÷îê

	const Point& start() const;

	const Point& end() const;

	// Ñåëåêòîðè-ìîäèô³êàòîðè òî÷îê

	Point& start();

	Point& end();

	// Ñåëåêòîðè êîîðäèíàò òî÷îê

	const double& startX() const;

	const double& startY() const;

	const double& endX() const;

	const double& endY() const;

	// Ñåëåêòîðè-ìîäèô³êàòîðè êîîðäèíàò òî÷îê

	double& startX();

	double& startY();

	double& endX();

	double& endY();

	// Îá÷èñëåííÿ äîâæèíè â³äð³çêà

	double length() const;

	// Îá÷èñëåííÿ â³äñòàí³ â³ä â³äð³çêà äî òî÷êè

	double distance(const Point&) const;

	// Ñåëåêòîð ID

	const int getID() const;

};



ostream& operator<<(ostream&, const Segment&);

double distance(const Segment&, const Point&);
#endif