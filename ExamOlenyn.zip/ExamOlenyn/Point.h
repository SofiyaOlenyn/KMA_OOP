﻿
#ifndef _POINT_H_

#define _POINT_H_


#include <iostream>

using namespace std;


class Point

{

private:

	static int freeID; //çàãàëüíèé äëÿ âñ³õ

	const int pointID; //äëÿ êîæíî¿ òî÷êè ñâ³é

	double _x;

	double _y;

public:

	Point(double x = 0, double y = 0);

	Point(const Point&);

	~Point();

	Point& operator=(const Point&);

	double& x();

	double& y();

	Point& vidobrazenya(char k);

	Point& povorot(double angle);

	const double& x()const;

	const double& y()const;

	const int getID() const;

	static int amount();

};
#endif


ostream& operator<<(ostream&, const Point&);

const Point operator+ (const Point& u, const Point& v);

Point& operator+=(Point&, const Point&);

bool operator==(const Point& u, const Point& v);

bool operator!=(const Point& u, const Point& v);
