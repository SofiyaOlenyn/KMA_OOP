
#ifndef _TrapeziumAxes_H_
#define _TrapeziumAxes_H_

#include <iostream>
#include "Point.h"
#include "Segment.h"
#include "Trapezium.h"
#include "TrapeziumBase.h"
using namespace std;
class TrapeziumBase; 
class TrapeziumAxes 
	:  public Trapezium

{

private:


	Point _a11, _a12,// a11 and a22 at the top
		_a21, _a22; 
	

public:
	class BadTrapeziumAxes {

	private:
		const string _reason;
	public:
		explicit BadTrapeziumAxes(string r = "=") : _reason(std::move(r)) {};
		~BadTrapeziumAxes() {};

		void diagnose() const {
			cerr  << _reason << endl;
		}
	};
	

	TrapeziumAxes(const double a11x = 0, const double a11y = 0,

		const double a12x = 0, const double a12y = 0,
		const double a21x = 0, const double a21y = 0,

		const double a22x = 0, const double a22y = 0);



	TrapeziumAxes(const Point& a11, const Point& a12, const Point& a21, const Point& a22);



	TrapeziumAxes(const TrapeziumAxes&);

	TrapeziumAxes(const TrapeziumBase&);


	~TrapeziumAxes() {};

	void cheakParalelnist();

	TrapeziumAxes& operator=(const TrapeziumAxes&);

	const Point& a11() const { return _a11; };
	const Point& a12() const { return _a12; };
	const Point& a21() const { return _a21; };
	const Point& a22() const { return _a22; };

	 Point& a11() { return _a11; };
     Point& a12()  { return _a12; };
	 Point& a21()  { return _a21; };
	 Point& a22()  { return _a22; };


	const Segment& A11_A12_side() const { return *(new Segment(a11(), a12())); }
	const Segment& A11_A21_side() const { return *(new Segment(a11(), a21())); }
	const Segment& A21_A22_side() const { return *(new Segment(a21(), a22())); }
	const Segment& A22_A12_side() const { return *(new Segment(a22(), a12())); }

	const Segment& mediana() const;

	double area() const;

	double perumetr() const {

		return A11_A12_side().length() + A11_A21_side().length() + A21_A22_side().length() + A22_A12_side().length();
	}

	void vidobrazenya(char k);

	void povorot(double angle);



};
ostream& operator << (ostream& out, const TrapeziumAxes& tr);
#endif