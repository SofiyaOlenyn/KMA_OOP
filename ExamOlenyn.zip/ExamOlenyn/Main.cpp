#include "Matrix.h"
#include "Point.h"
#include "Segment.h"
#include "TrapeziumAxes.h"
#include "TrapeziumBase.h"
#include "Trapezium.h"
#include "Register.h"
#include <iostream>
using namespace std;

//TASK 1,2 IN FILES Register.h  and Register.cpp
//TASK 3  IN FILES Matrix.h  and Matrix.cpp
//TASK 4  at the begginng of the file Point.cpp
//TASK 5  at the begginng of the file Segment.cpp
//TASK 6,7,8,9  in the files TrapeziumAxes.cpp ,TrapeziumAxes.h, TrapeziumBase.h, TrapeziumBase.cpp
//TSK 10 in the file Trapezium.h
int main()
{
	{cout << "///////////////// TASK 1 ///////////////" << endl;
	cout << "Create registers r1 and fill it in with random values:" << endl;
		Register r1;
		
		for (int i = 0; i < 32; i++)
		{
			r1.set_a(i, (bool)(rand() % 2));
			r1.set_b(i, (bool)(rand() % 2));
			r1.set_x(i, (bool)(rand() % 2));
			r1.set_y(i, (bool)(rand() % 2));
		}
		cout << r1<<endl;
		cout << "#Lets swipe a with b:" << endl;
		r1.swap('a','b');
		cout << r1 << endl;
		cout << "#Lets swipe a with x:" << endl;
		r1.swap('a', 'x');
		cout << r1 << endl;
		cout << "#Lets swipe a with y:" << endl;
		r1.swap('a', 'y');
		cout << r1 << endl;
		cout << "#Lets swipe b with x:" << endl;
		r1.swap('b', 'x');
		cout << r1 << endl;
		cout << "#Lets swipe b with y:" << endl;
		r1.swap('b', 'y');
		cout << r1 << endl;
		cout << "#Lets swipe x with y:" << endl;
		r1.swap('y', 'x');
		cout << r1 << endl;
		cout << "///////////////// TASK 2 ///////////////" << endl;
		cout << "Lets test bitwise operations:" << endl<<"P.S. The result is in the auxiliary register X !"<<endl;
		cout << "# a and b" << endl;
		r1.a_and_b();
		cout << r1 << endl;
		cout << "# a or b" << endl;
		r1.a_or_b();
		cout << r1 << endl;
		cout << "# not a" << endl;
		r1.not_a();
		cout << r1 << endl;
		cout << "# not b" << endl;
		r1.not_b();
		cout << r1 << endl;

	}
	{cout << "///////////////// TASK 3 ///////////////" << endl;
	
		cout << "------Create Matrix m1(2):" << endl;
		Matrix m1(2);
		cout << m1 << endl;
		cout << "Size of Matrix m1(2):"<<m1.size() << endl;
		
		cout << "Fill Matrix m1(2):" << endl;
		for (int i = 1; i <= m1.size(); i++)
			for (int j = 1; j <= m1.size(); j++)
				m1(i, j) = (2+j) - i;
		cout << m1;
		cout << "------Create Matrix m2(2):" << endl;
		Matrix m2(2);
		cout << "Size of Matrix m2(2):" << m2.size() << endl;
		cout << m2 << endl;
		cout << "Fill Matrix m2(4):" << endl;
		for (int i = 1; i <= m2.size(); i++)
			for (int j = 1; j <= m2.size(); j++)
				m2(i, j) = 1-i+j;
		cout << m2;


		cout << "Test operation + " << endl << "m1+m2" << endl;
		cout << (m1 + m2) << endl;
		cout << "Test operation - " << endl << "m1-m2" << endl;
		cout << (m1 - m2) << endl;
		cout << "Test operation * " << endl << "m1*m2" << endl;
		cout << (m1 * m2) << endl;
		cout << "------Create Matrix m3(5):" << endl;
		Matrix m3(5);

		cout << "Size of Matrix m3(5):" << m2.size() << endl;
		cout << m3 << endl;
		cout << "Fill Matrix m3(5):" << endl;
		for (int i = 1; i <= m3.size(); i++)
			for (int j = 1; j <= m3.size(); j++)
				m3(i, j) =  3* i + j;
		cout << m3;
		cout << "Lets try operator + on matrices of different dimensions " << endl << "m1+m3 :" << endl;
		cout << (m1 + m3) << endl;
	
	}
	{
		cout << "///////////////// TASK 4 ///////////////" << endl;
		Point p1(10, 5), p2(-3, 4);
		cout << p1 << endl << p2 <<endl ;
		cout << "Test vidobrazenya(X)" << endl;
		cout << "p1.vidobrazenya('x')"<<endl;
		p1.vidobrazenya('x');
		cout << p1<<endl;
		cout << "p2.vidobrazenya('x')" << endl;
		p2.vidobrazenya('x');
		cout << p2 << endl;
		cout << "Now test our new points - vidobrazenya(Y)" << endl;
		cout << "p1.vidobrazenya('y')" << endl;
		p1.vidobrazenya('y');
		cout << p1 << endl;
		cout << "p2.vidobrazenya('y')" << endl;
		p2.vidobrazenya('y');
		cout << p2 << endl;
		cout << "Test povorot" << endl;
		cout << "p1:" << p1 << endl;
		cout << "Test povorot p1.povorot(3.14);" << endl;
		cout << p1.povorot(3.14)<<endl;
		cout << "Test povorot p1.povorot(-3.14);" << endl;
		cout << p1.povorot(-3.14) << endl;
	}
	{
		cout << "///////////////// TASK 5 ///////////////" << endl;
		Point p1(1, 1), p2(29, 5), p3(0, -1), p4(9, -4);
		Segment s1(p1,p2), s2(p3,p4);
		cout << s1 << endl << s2 << endl;
		cout << "Test vidobrazenya(X)" << endl;
		cout << "s1.vidobrazenya('x')" << endl;
		s1.vidobrazenya('x');
		cout << s1 << endl;
		cout << "s2.vidobrazenya('x')" << endl;
		s2.vidobrazenya('x');
		cout << s2 << endl;
		cout << "Now test our new points - vidobrazenya(Y)" << endl;
		cout << "s1.vidobrazenya('y')" << endl;
		s1.vidobrazenya('y');
		cout << s1 << endl;
		cout << "s2.vidobrazenya('y')" << endl;
		s2.vidobrazenya('y');
		cout << s2 << endl;
		cout << "Test povorot" << endl;
		cout << "s1:" << s1 << endl;
		cout << "Test povorot s1.povorot(3.14);" << endl;
		cout << s1.povorot(3.14) << endl;
		cout << "Test povorot s1.povorot(-3.14);" << endl;
		cout << s1.povorot(-3.14) << endl;
	}
	try {
		cout << "///////////////// TASK 6 ///////////////" << endl;
		TrapeziumAxes trapezium_axes1( 3, 3, 4, 3, 2, 1, 5, 1);
		cout << trapezium_axes1 << endl;
		Point p1(10, 5);
		Point p2(20, 5), p3(15, 2), p4(18, 2), p5(16, 5);
		cout << "====TrapeziumAxes tr1(p1, p2, p3, p4)" << endl;
		TrapeziumAxes tr1(p1, p2, p3, p4);
		cout << tr1<<endl;
		cout << "====TrapeziumAxes  tr2(10,0,20,0,5,-5,26,-5)" << endl;
		TrapeziumAxes tr2(10,0,20,0,5,-5,26,-5);
		cout << tr2<<endl;
		cout << "====TrapeziumAxes  tr3(tr1)" << endl;
		TrapeziumAxes tr3(tr1);
		cout << tr3<< endl;
		cout << "====tr3 = tr2;" << endl;
		tr3 = tr2;
		cout<<tr3<< endl;
		cout << "====Test getters" << endl;
		cout << "tr1.a11(): " << tr1.a11() << " tr1.a12(): " << tr1.a12() << " tr1.a21(): "
			<< tr1.a21() << "  tr1.a22(): " << tr1.a22() << endl;
		cout << "====Test setters" << endl;
		cout << "tr1.a11()=p5(18,20)" << endl;
		(tr1.a11()) = p5;
		cout << tr1 << endl;
		cout << "====Test sides" << endl;
		cout << "tr1.A11_A12_side(): " << (tr1.A11_A12_side())
			<< "   tr1.A11_A21_side(): " << (tr1.A11_A21_side()) 
			<< "   tr1.A21_A22_side(): " << (tr1.A21_A22_side())
			<< "   tr1.A22_A12_side(): " << (tr1.A22_A12_side()) << endl;
		cout << "====task 9  mediana   " <<tr1.mediana()<< endl;
		cout << "====perumetr   " << tr1.perumetr() << endl;
		cout << "====area   " << tr1.area() << endl;
		tr1.vidobrazenya('x');
		cout << "====vidobrazenya X           " << tr1<< endl;
		tr1.vidobrazenya('y');
		cout << "====vidobrazenya Y         " << tr1 << endl;
		tr1.povorot(3.14);
		cout << "====povorot  3.14  " << tr1 << endl;
		cout << "!!!!!!!!!!!!!!!!!!Change a little our Trapezium and then test again " << endl;
		(tr1.a11() = (Point(13, 15)));
		(tr1.a12() = (Point (14, 15)));
		(tr1.a21() = (Point(10, 5)));
		(tr1.a22() = (Point(14, 5)));
		cout << "====new Trapezium:" << tr1 << endl;
		cout << "====Test sides" << endl;
		cout << "====tr1.A11_A12_side(): " << (tr1.A11_A12_side())
			<< "   tr1.A11_A21_side(): " << (tr1.A11_A21_side())
			<< "   tr1.A21_A22_side(): " << (tr1.A21_A22_side())
			<< "   tr1.A22_A12_side(): " << (tr1.A22_A12_side()) << endl;
		(tr1.vidobrazenya('x'));
		cout << "====vidobrazenya X           " << tr1 << endl;
		tr1.vidobrazenya('y');
		cout << "====vidobrazenya Y         " << tr1 << endl;
		tr1.povorot(3.14);
		cout << "====povorot  3.14  " << tr1 << endl;
	}
	catch (const TrapeziumAxes::BadTrapeziumAxes& bad)
	{
		bad.diagnose();
	}
	try {
		cout << "//     Test exeptions      ->  TrapeziumAxes  tr2(1,1,1,41,5,6,7,8)" << endl;
		TrapeziumAxes tr2(1, 1, 1, 1, 5, 6, 7, 8);

	}
	catch (const TrapeziumAxes::BadTrapeziumAxes& bad)
	{
		bad.diagnose();
	}
	try {
		
		cout << "///////////////// TASK 7 ///////////////" << endl;
		Point p1(10, 5);
		Point p2(20, 5), p3(15, 2), p4(18, 2), p5(16, 5);
		Segment s1(p1,p2);
		Segment s2(p3,p4);
		cout << "====TrapeziumBase  tr1(s1,s2)" << endl;
		TrapeziumBase tr1(s1,s2);
		cout << tr1 << endl;
		cout << "====TrapeziumBase  tr3(tr1)" << endl;
		TrapeziumBase tr3(tr1);
		cout << tr3 << endl;
		cout << "====tr3 = tr1;" << endl;
		tr3 = tr1;
		cout << tr3 << endl;
		cout << "====Test getters" << endl;
		cout << "tr1.a11(): " << tr1.a11() << " tr1.a12(): " << tr1.a12() << " tr1.a21(): "
			<< tr1.a21() << "  tr1.a22(): " << tr1.a22() << endl;
		cout << "====Test setters" << endl;
		cout << "tr1.a11()=p5(18,20)" << endl;
		(tr1.a11()) = p5;
		cout << tr1 << endl;
		cout << "====Test sides" << endl;
		cout << "tr1.A11_A12_side(): " << (tr1.A11_A12_side())
			<< "   tr1.A11_A21_side(): " << (tr1.A11_A21_side())
			<< "   tr1.A21_A22_side(): " << (tr1.A21_A22_side())
			<< "   tr1.A22_A12_side(): " << (tr1.A22_A12_side()) << endl;
		cout << "====task 9  mediana   " << tr1.mediana() << endl;
		cout << "====perumetr   " << tr1.perumetr() << endl;
		cout << "====area   " << tr1.area() << endl;
		tr1.vidobrazenya('x');
		cout << "====vidobrazenya X           " << tr1 << endl;
		tr1.vidobrazenya('y');
		cout << "====vidobrazenya Y         " << tr1  << endl;
		tr1.povorot(3.14);
		cout << "====povorot  3.14  " <<tr1 << endl;
		cout << "!!!!!!!!!!!!!!!!!!Change a little our Trapezium and then test again " << endl;
		(tr1.a11() = (Point(13, 15)));
		(tr1.a12() = (Point(14, 15)));
		(tr1.a21() = (Point(10, 5)));
		(tr1.a22() = (Point(15, 5)));
		cout << "====new Trapezium:" << tr1 << endl;
		cout << "====Test sides" << endl;
		cout << "====tr1.A11_A12_side(): " << (tr1.A11_A12_side())
			<< "   tr1.A11_A21_side(): " << (tr1.A11_A21_side())
			<< "   tr1.A21_A22_side(): " << (tr1.A21_A22_side())
			<< "   tr1.A22_A12_side(): " << (tr1.A22_A12_side()) << endl;
		tr1.vidobrazenya('x');
		cout << "====vidobrazenya X           " << tr1 << endl;
		tr1.vidobrazenya('y');
		cout << "====vidobrazenya Y         " << tr1 << endl;
		tr1.povorot(3.14);
		cout << "====povorot  3.14  " << tr1 << endl;

	}
	catch (const TrapeziumBase::BadTrapeziumBase& bad)
	{
		bad.diagnose();
	}
	try {
		cout << "//       Test exeptions ->  TrapeziumBase  tr2(s1,s1)" << endl;
		Point p2(20, 5), p3(15, 2);
		Segment s1(p2, p2);
		TrapeziumBase tr2(s1,s1);

	}
	catch (const TrapeziumBase::BadTrapeziumBase& bad)
	{
		bad.diagnose();
	}
	{


		cout << "////////////TASK 8////////////////////" << endl;
	Point p1(10, 5);
	Point p2(20, 5), p3(15, 2), p4(18, 2);
	TrapeziumAxes tr1(p1, p2, p3, p4);
	Segment s1(1, 3, 2, 3);
	Segment s2(-1, 0, 4, 0);
	cout <<"Test mutually convertible constructors"<<endl << "Create  TrapeziumBase tr2(s1, s2): " << endl;
	TrapeziumBase tr2(s1, s2);
	cout << tr2 << endl;
	cout << "Create TrapeziumAxes tr3(tr2): " << endl;
	TrapeziumAxes tr3(tr2);
	cout << tr3 << endl;
	cout << "Create TrapeziumBase tr4(tr3): " << endl;
	TrapeziumBase tr4(tr3);
	cout << tr4 << endl;

	}
	system("pause");
}