

#include "Register.h"
#include <iostream>
#include <math.h>
using namespace std;


Register::Register()
{
	for (int i = 0; i < 32; ++i)
	{
		a[i] = false;
		b[i] = false;
		x[i] = false;
		y[i] = false;
	}
}
bool Register::get_a(int i)
{
	if (i >= 0 || i < 32)
		return a[i];

	return false;
}
bool Register::get_b(int i)
{
	if (i >= 0 || i < 32)
		return b[i];
	
	return false;
}

bool Register::get_x(int i)
{
	if (i >= 0 || i < 32)
		return x[i];
	
	return false;
}

bool Register::get_y(int i)
{
	if (i >= 0 || i < 32)
		return y[i];
	
	return false;
}

void Register::set_a( int i,bool value)
{
	if (i >= 0 && i < 32)
		a[i] = value;
}

void Register::set_b(int i, bool value)
{
	if (i >= 0 && i < 32)
		b[i] = value;
}

void Register::set_x(int i, bool value)
{
	if (i >= 0 && i < 32)
		x[i] = value;
}

void Register::set_y(int i, bool value)
{
	if (i >= 0 && i < 32)
		y[i] = value;
}


void Register::swap(char r1,char r2) {
	if ((r1 == 'a' && r2 == 'b') || (r2 == 'a' && r1 == 'b')) {
		for (int i = 0; i < 32; ++i)
		{
			bool temp = a[i];
				a[i] = b[i];
				b[i] = temp;
		}
	}
	if ((r1 == 'a' && r2 == 'x') || (r2 == 'a' && r1 == 'x')) {
	
		for (int i = 0; i < 32; ++i)
		{
			bool temp = x[i];
			x[i] = a[i];
			a[i] = temp;
		}
	}
	if ((r1 == 'a' && r2 == 'y') || (r2 == 'a' && r1 == 'y')) {
		for (int i = 0; i < 32; ++i)
		{
			bool temp = y[i];
			y[i] = a[i];
			a[i] = temp;
		}
	}
	if ((r1 == 'b' && r2 == 'x') || (r2 == 'b' && r1 == 'x')) {
		for (int i = 0; i < 32; ++i)
		{
			bool temp = x[i];
			x[i] = b[i];
			b[i] = temp;
		}
	}
	if ((r1 == 'b' && r2 == 'y') || (r2 == 'b' && r1 == 'y')) {
		for (int i = 0; i < 32; ++i)
		{
			bool temp = y[i];
			y[i] = b[i];
			b[i] = temp;
		}
	}
	if ((r1 == 'x' && r2 == 'y') || (r2 == 'x' && r1 == 'y')) {
		for (int i = 0; i < 32; ++i)
		{
			bool temp = x[i];
			x[i] = y[i];
			y[i] = temp;
		}
	}

}


void Register::a_and_b()
{
	for (int i = 0; i < 32; ++i)
		x[i] = a[i] && b[i];
	
}

void Register::a_or_b()
{
	for (int i = 0; i < 32; ++i)
		x[i] = a[i] || b[i];
	
}

void Register::not_a()
{
	for (int i = 0; i < 32; ++i)
		x[i] = !a[i];
	
}

void Register::not_b()
{
	for (int i = 0; i < 32; ++i)
		x[i] = !b[i];
	
}
ostream& operator << (ostream& os, Register& r) {

	cout << "--REGISTERS:  " << endl;
		cout<< "register A:  ";

		for (int i = 0; i < 32; i++)
		{
			if (r.get_a(i))
				cout << "1 ";
			else
				cout << "0 ";
		}
		cout << endl;
		cout << "register B: ";

		for (int i = 0; i < 32; i++)
		{
			if (r.get_b(i))
				cout << "1 ";
			else
				cout << "0 ";
		}

		cout << endl;
		cout << "register X:";

		for (int i = 0; i < 32; i++)
		{
			if (r.get_x(i))
				cout << "1 ";
			else
				cout << "0 ";
		}


		cout << endl;
		cout << "register Y: ";

		for (int i = 0; i < 32; i++)
		{
			if (r.get_y(i))
				cout << "1 ";
			else
				cout << "0 ";
		}

		
		return os;
}


