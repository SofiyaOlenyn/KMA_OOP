#pragma once
#ifndef _MATRIX_H_

#define _MATRIX_H_
#include <ostream>
using namespace std;
class Matrix {
private:   
	size_t _size; 
	double** _matrix;
		
			
  
public:  
	Matrix(const Matrix&);
	Matrix& operator=(const Matrix&) = delete; 
	Matrix( const size_t  n);
  ~Matrix(); 
 double& operator()(size_t, const size_t ); 
 double operator()(size_t, const size_t ) const;
	  size_t size() const {return _size;} 
		  
};

ostream& operator<<(ostream&, const Matrix&); 

const Matrix operator+ (const Matrix& u, const Matrix& v);
const Matrix operator- (const Matrix& u, const Matrix& v);
const Matrix operator* (const Matrix& u, const Matrix& v);



#endif