#include "TrapeziumBase.h"
#include "TrapeziumAxes.h"
#include "Point.h"
#include <iostream>
#include <math.h>
using namespace std;
TrapeziumBase::TrapeziumBase(const ::Segment& a, const ::Segment& b) : _a11(a.start()), _a12(a.end()), _a21(b.start()), _a22(b.end()),
_A11_A12_side(0), _A21_A22_side(0),_A11_A21_side(0), _A22_A12_side(0)

{
	cheakParalelnist();
};

TrapeziumBase::TrapeziumBase(const TrapeziumBase& a):
	_a11(a.a11()), _a21(a.a21()), _a12(a.a12()), _a22(a.a11()), _A11_A12_side(0), _A21_A22_side(0), _A11_A21_side(0), _A22_A12_side(0)

{
	//v kopiyvalnomy konstructori ne treba perevirytu na pravulnist trapezii bo yakshcho trapeziya isnye to vona vze pravulnya

};
TrapeziumBase::TrapeziumBase(const TrapeziumAxes& a) :
	_a11(a.a11()), _a21(a.a21()), _a12(a.a12()), _a22(a.a22()), _A11_A12_side(0), _A21_A22_side(0), _A11_A21_side(0), _A22_A12_side(0)
	//v kopiyvalnomy konstructori ne treba perevirytu na pravulnist trapezii bo yakshcho trapeziya isnye to vona vze pravulnya
{};



TrapeziumBase& TrapeziumBase::operator=(const TrapeziumBase& t) {
	_a11 = t.a11(); _a12= t.a12(); _a21 = t.a21(); _a22 = t.a22();
	delete _A11_A12_side; delete _A21_A22_side; 
	delete _A11_A21_side; delete _A22_A12_side;
	_A11_A21_side= _A22_A12_side=_A11_A12_side = _A21_A22_side = 0;
	return *this;

}
const ::Segment& TrapeziumBase::mediana() const {
	Point A(((a11().x() + a21().x()) / 2), ((a11().y() + a21().y()) / 2));
	Point B(((a12().x() + a22().x()) / 2), ((a12().y() + a22().y()) / 2));
	return *(new ::Segment(A, B));
}

void TrapeziumBase::cheakParalelnist() {
	//tochku ne mayt zbigatus
	if (a21() == a12() || a22() == a12() || a11() == a12() || a21() == a11() || a21() == a22() || a11() == a22() ||
		// yakshcho kytovi koeficientu ne rivni to pryami ne paralelni
		(((a12().y() - a11().y()) / (a12().x() - a11().x())) != ((a22().y() - a21().y()) / (a22().x() - a21().x())))
		) {
		throw BadTrapeziumBase(" !BAD TrapeziumBase");

	}
}
const TrapeziumBase::Segment& TrapeziumBase::A11_A12_side() const
{
	if (_A11_A12_side == 0)
		_A11_A12_side = new TrapeziumBase::Segment(_a11, _a12);
	return *_A11_A12_side;
}

const TrapeziumBase::Segment& TrapeziumBase::A21_A22_side() const
{
	if (_A21_A22_side == 0)
		_A21_A22_side = new TrapeziumBase::Segment(_a21, _a22);
	return *_A21_A22_side;
}
const TrapeziumBase::Segment& TrapeziumBase::A11_A21_side() const
{
	if (_A11_A21_side == 0)
		_A11_A21_side = new TrapeziumBase::Segment(_a11, _a21);
	return *_A11_A21_side;
}
const TrapeziumBase::Segment& TrapeziumBase::A22_A12_side() const
{
	if (_A22_A12_side == 0)
		_A22_A12_side = new TrapeziumBase::Segment(_a22, _a12);
	return *_A22_A12_side;
}

void TrapeziumBase::vidobrazenya(char k) {
	this->_a11.vidobrazenya(k);
	this->_a12.vidobrazenya(k);
	this->_a21.vidobrazenya(k);
	this->_a22.vidobrazenya(k);
	

};

void TrapeziumBase::povorot(double k) {
	this->_a11.povorot(k);
	this->_a12.povorot(k);
	this->_a21.povorot(k);
	this->_a22.povorot(k);
	

}

double TrapeziumBase::area() const {   

	
	double mediana = (A11_A12_side().length() + A21_A22_side().length())/2;
	return mediana * sqrt(A11_A21_side().length() * (A11_A21_side().length() - (pow((((A21_A22_side().length() - A11_A12_side().length()), 2)
		+ pow(A11_A21_side().length(), 2)
		- pow(A22_A12_side().length(), 2)) / (2 * (A21_A22_side().length() - A11_A12_side().length())), 2))));
		

}

ostream& operator<<(ostream& out, const TrapeziumBase& tr) {

	

	out << " # TrapeziumBase:" << endl << "|" << tr.a11() << ";" << tr.a12() << " |" << endl
		<< "| " << tr.a21() << "; " << tr.a22() << " |" << endl << " # middle line:  " << tr.mediana()  <<
		" # perumetr: " << tr.perumetr() << endl << " # area: " << tr.area() << endl;

		return out;
	
}