#include <iostream>



using namespace std;

class Register
{
private:
	bool a[32], b[32], x[32], y[32];
public:
	Register();

	bool get_a(int);

	bool get_b(int);
	
	bool get_x(int);

	bool get_y(int);

	void set_a(int,bool);

	void set_b(int, bool);
	void set_x(int, bool);

	void set_y(int, bool);
	
	void swap(char,char);


	void a_and_b();

	void a_or_b();
	void not_a();
	void not_b();
	


};
ostream& operator << (ostream& out,  Register& matrix);