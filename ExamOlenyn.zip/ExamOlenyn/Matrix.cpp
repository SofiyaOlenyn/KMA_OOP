#include "Matrix.h"
#include <iostream>

using namespace std;
Matrix::Matrix(const size_t  n) : _size(n) {
	 
	_matrix=new double*[_size];
	
	for(unsigned int i=0; i<_size; i++)  
		_matrix[i]=new double [_size];

	for(unsigned int k=0; k<_size; k++)       
		for(unsigned int j=0; j<_size; j++)  
			_matrix[k][j]=0;   
	
} 

Matrix::~Matrix()
{
	for(unsigned int i=0; i<_size; i++)  
		delete [] _matrix[i]; 

	delete [] _matrix;    return; } 

double& Matrix::operator()(const size_t i, const size_t  j) 
{    return _matrix[i-1][j-1]; } 

double Matrix::operator()(const size_t i, const size_t  j) const
{    return _matrix[i-1][j-1]; } 

const Matrix operator+ (const Matrix& u, const Matrix& v) {
	Matrix temp( u.size());
	if (u.size() != v.size()) {
		cout << "!!!!! it is not possible to add different dimension matrices" << endl;
		return temp;
	}
	
	for (unsigned int i = 1; i <= u.size(); i++) {
		for (unsigned int j = 1; j <= u.size(); j++) {
			temp(i, j)=u(i,j)+ v(i, j);
		}
			
	}
	return temp;
}
const Matrix operator- (const Matrix& u, const Matrix& v) {
	Matrix temp(u.size());

	if (u.size() != v.size()) {
		cout << "!!!!! it is not possible to subtract different dimension matrices" << endl;
		return temp;
	}
	for (unsigned int i = 1; i <= u.size(); i++) {
		for (unsigned int j = 1; j <= u.size(); j++) {
			temp(i, j) = u(i, j) - v(i, j);
		}

	}
	return temp;
}
const Matrix operator* (const Matrix& u, const Matrix& v) {
	Matrix temp(u.size());
	if(u.size()!=v.size()) {
		cout << "!!!!! it is not possible to multiply different dimension matrices" << endl;
		return temp;
	}
	for (unsigned int i = 1; i <= u.size(); ++i)
	{
		for (unsigned int j = 1; j <= u.size(); ++j)
		{
			temp(i,j) = 0;
			for (unsigned int k = 1; k <= u.size(); ++k)
				temp(i,j) += u(i,k) * v(k,j);
		}
	}
	return temp;
}

 Matrix::Matrix(const Matrix& m):_size(m.size()) {

	 _matrix = new double* [_size];
	  
	 for (unsigned int i = 0; i < _size; i++)
		 _matrix[i] = new double[_size];
	 
	 for (unsigned int k = 0; k < _size; k++)
		 for (unsigned int j = 0; j < _size; j++)
			 _matrix[k][j] = m._matrix[k][j];
	
}
ostream& operator<<(ostream& os, const Matrix& M) 
{    for(unsigned int i=1; i<=M.size(); i++) {  
	for(unsigned int j=1; j<=M.size(); j++)   
		cout<<M(i, j)<<' ';       cout<<endl;    } 
return os; } 