#define _DEBUG_
#ifndef _Trapezium_H_
#define _Trapezium_H_
#include "Point.h"
#include "Segment.h"

class Trapezium
{
public:

	virtual const Point& a11() const =0 ;
	virtual const Point& a12() const = 0;
	virtual const Point& a21() const = 0;
	virtual const Point& a22() const = 0;

	virtual Point& a11() = 0;
	virtual Point& a12() = 0;
	virtual Point& a21() = 0;
	virtual Point& a22() = 0;
	
	virtual double area() const = 0;

	virtual double perumetr() const = 0;
	virtual void vidobrazenya(char k) = 0;
   virtual void povorot(double angle) = 0;
};
#endif