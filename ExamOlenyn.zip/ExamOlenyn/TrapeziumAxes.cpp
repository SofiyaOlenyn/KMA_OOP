﻿#include "TrapeziumAxes.h"
#include "TrapeziumBase.h"
#include "Point.h"
#include <iostream>
#include <math.h>
using namespace std;

TrapeziumAxes::TrapeziumAxes(const double a11x, const double a11y,

	const double a12x, const double a12y ,
	const double a21x , const double a21y,

	const double a22x , const double a22y):_a11(a11x, a11y), _a12(a12x, a12y), _a21(a21x, a21y), _a22(a22x, a22y)
{
	cheakParalelnist();
};

TrapeziumAxes::TrapeziumAxes(const Point& a11, const Point& a12, const Point& a21, const Point& a22)
	:_a11(a11), _a12(a12), _a21(a21), _a22(a22) {
	cheakParalelnist();
};

//v kopiyvalnomy konstructori ne treba perevirytu na pravulnist trapezii bo yakshcho trapeziya isnye to vona vze pravulnya
TrapeziumAxes::TrapeziumAxes(const TrapeziumAxes& a ):_a11(a.a11()) ,_a12(a.a12()),_a21(a.a21()),_a22(a.a22()) {
	
	
}
TrapeziumAxes::TrapeziumAxes(const TrapeziumBase& a) : _a11(a.a11()), _a12(a.a12()), _a21(a.a21()), _a22(a.a22()) {


}

TrapeziumAxes&  TrapeziumAxes::operator=(const TrapeziumAxes& a) {
	_a11 = a.a11();
	_a12 = a.a12();
	_a21 = a.a21();
	_a22 = a.a22();
	return *this;
}
void TrapeziumAxes::cheakParalelnist(){
      	//tochku ne mayt zbigatus
	if (a21() == a12() || a22() == a12() || a11() == a12() || a21() == a11() || a21() == a22() || a11() == a22() 
		||
		// yakshcho kytovi koeficientu ne rivni to pryami ne paralelni
		(((a12().y()- a11().y())/(a12().x() - a11().x())) != ((a22().y() - a21().y()) / (a22().x() - a21().x())))
		
		) {
		throw BadTrapeziumAxes(" !BAD TrapeziumAxes");

	}
}
double TrapeziumAxes::area() const
{

	double mediana = (A11_A12_side().length() + A21_A22_side().length()) / 2;
	return mediana * sqrt(A11_A21_side().length() * (A11_A21_side().length() - (pow((((A21_A22_side().length() - A11_A12_side().length()), 2)
		+ pow(A11_A21_side().length(), 2)
		- pow(A22_A12_side().length(), 2)) / (2 * (A21_A22_side().length() - A11_A12_side().length())), 2))));

}
void TrapeziumAxes::vidobrazenya(char k) {
	this->_a11.vidobrazenya(k);
	this->_a12.vidobrazenya(k);
	this->_a21.vidobrazenya(k);
	this->_a22.vidobrazenya(k);
	
}

void TrapeziumAxes::povorot(double k) {
	this->_a11.povorot(k);
	this->_a12.povorot(k);
	this->_a21.povorot(k);
	this->_a22.povorot(k);


}
const Segment& TrapeziumAxes::mediana() const
{
	Point A(((a11().x() + a21().x()) / 2), ((a11().y() + a21().y()) / 2));
	Point B(((a12().x() + a22().x()) / 2), ((a12().y() + a22().y()) / 2));
	return *(new Segment(A, B));
}

ostream& operator << (ostream& out, const TrapeziumAxes& tr)
{

	out << " # TrapeziumAxes:" << endl << "|" << tr.a11() << ";" << tr.a12() << " |" << endl
		<< "| " << tr.a21() << "; " << tr.a22() << " |" << endl << " # middle line:  " << tr.mediana() <<
		" # perumetr: " << tr.perumetr() << endl << " # area: " << tr.area() << endl;

	return out;
}
