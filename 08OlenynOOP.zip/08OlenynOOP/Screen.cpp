#define _CRT_SECURE_NO_WARNINGS


#include "Screen.h"
#include <iostream>
using namespace std;
const int Screen::maxHeight = 50;
const int Screen::maxWidth = 50;
const char Screen::_filler = '*';

Screen::Screen(int width, int height, const char* pc) : _height(height), _width(width), _cursor(0)
{
	if (_height > Screen::maxHeight)
	{
		_height = Screen::maxHeight;
	}

	if (_width > Screen::maxWidth)
	{
		_width = Screen::maxWidth;
	}


	_wContent = new char[_width * _height + 1];

	if (pc == 0)
	{
		for (int i = 0, length = _width * _height; i < length; ++i)
		{
			_wContent[i] = Screen::_filler;
		}

		_wContent[_width * _height] = '\0';
	}
	else
	{
		strcpy(_wContent, pc);
	}

	return;
}


Screen::~Screen() { delete[] _wContent; }

const Screen& Screen::home() const { 
	_cursor = 0; 
	return *this; } 

Screen& Screen::home() {
	_cursor = 0;
	return *this; }

const Screen& Screen::move() const {



	if ((++_cursor) >= _width * _height) _cursor = 0; 


return *this; } 



Screen& Screen::move()
{
	if ((_width * _height) < (++_cursor))
	{
		_cursor = 0;
	}

	return *this;
}
 const Screen& Screen::back() const {    if(--_cursor<0) _cursor=0;    return *this; } 
 
 Screen& Screen::back()
 {
	 if (--_cursor < 0)
	 {
		 _cursor = (_width * _height - 1);
	 }

	 return *this;
 }
 
 
 
 const Screen& Screen::show() const {
	 size_t  cursor = _cursor; 
	
	 cout<<"cursor="<<_cursor<<endl; home();
	 
	 for(size_t  i=0; i<_height; i++) {
		    
		 for(size_t  j=0; j<_width; j++) {  
			 cout<<get(); move();   
		 }       cout<<endl;   
	 }    _cursor=_cursor; 
	
	 return *this; }
 Screen& Screen::show()
 {
	 home();
	 cout << "___________________________\n";
	 for (int i = 0; i < _height; ++i)
	 {
		 for (int j = 0; j < _width; ++j)
		 {
			 cout << get();
			 move();
		 }

		 cout << endl;
	 }
	 cout << "___________________________\n";

	 return *this;
 }
 const Screen& Screen::move(const int  i, const int  j) const {
	
	 if((i>=_height)||(j>=_width)) _cursor=0;  
	 else _cursor=_width*i+j;    return *this; }

 Screen& Screen::move(int i, int j)
 {
	 if ((i >= _height) || (j >= _width))
	 {
		 _cursor = 0;
	 }
	 else
	 {
		 _cursor = (i * j);
	 }

	 return *this;
 }
 Screen& Screen::clear()
 {
	 for (int i = 0, length = _width * _height; i < length; ++i)
	 {
		 _wContent[i] = Screen::_filler;
	 }

	 _wContent[_width * _height] = '\0';

	 return *this;
 }
 char Screen::get() const { return *(_wContent + _cursor); } 

 Screen& Screen::set(char ch)
 {
	 _wContent[_cursor] = ch;

	 return *this;
 }
 ostream& operator<<(ostream& os, const Screen& s)
 {
	 return os << endl << "|Width: " << s.width() << "|\n|Height: " << s.height() << "|\n|Content: " << s.content() <<
		 "|\n";
 }

 void doActionConst(const Screen& s, ConstAction act, int n)
 {
	 for (auto i = 0; i < n; i++)
	 {
		 (s.*act)();
	 }
 }

 void doActionNonConst(Screen& s, NonConstAction act, int n)
 {
	 for (auto i = 0; i < n; i++)
	 {
		 (s.*act)();
	 }
 }

 const Screen& Screen::showCurrent() const
 {
	 cout << _wContent[_cursor];

	 return *this;
 }
