#ifndef U_QUEUEARRAY_H
#define U_QUEUEARRAY_H
#include "Queue.h"
#include <string>
#include <iostream>;
#include <assert.h>
using namespace std;
template <typename T>
class QueueArray :  public Queue<T> {

public:
	class BadQueueArray;

	QueueArray(const int size = _default);

	

	~QueueArray();

	bool empty() const;

	bool full() const;

	const T& front() const;

	void pop();

	void put(const T& value);

	int capacity() const { 
		return _size;
	};

	int size() const {      return _amountOfElements; }


private:
	 static const int _boq;

	static const int _default;

	int _size;
	int _amountOfElements;

	int _front;
	int _back;
	T* _allocator;

	


	QueueArray<T>(const QueueArray<T>& qArray)=delete;
	QueueArray<T> operator=(const QueueArray<T>&)=delete;
};

template <class T>
const int QueueArray<T>::_boq = -1;

template <class T>
const int QueueArray<T>::_default = 50;

template <class T>
QueueArray<T>::QueueArray(const int size) 
	

{
	if (size <= 0) {
		_size = _default;
	}
	else {
		_size = size;
	}

	_front = 0;
	_back = _size - 1;
	_amountOfElements = 0;
	_allocator = new T[_size];

	return;
};


template <class T>
bool QueueArray<T>::empty() const
{
	return (size() == 0);
};

template <class T>
bool QueueArray<T>::full() const
{
	return (size() == capacity());
};

template <typename T>
const T& QueueArray<T>::front() const {

	 assert(!empty());
	 return (_allocator)[_front];

}


template <class T>
void QueueArray<T>::pop() {

	assert(!empty());
	
	if  (!empty()) {
		     _amountOfElements--;
		     _front = ((_front + 1) % _size);
	}
	else {
		throw BadQueueArray("Empty array");
	}

}

template <class T>
void QueueArray<T>::put(const T& value)
{
	if (!full())
	{
		_back = ((_back + 1) % (capacity()));
		
		_amountOfElements++;

		_allocator[_back] = value;
	}
	else
		throw BadQueueArray("Full array");
}


template <class T>
class QueueArray<T>::BadQueueArray
{
public:
	BadQueueArray(string s) :
		_trouble(s) {};
	const string& getTrouble() const
	{
		return _trouble;
	}
private:
	 
	  string _trouble;

};

template <class T>
QueueArray<T>::~QueueArray() {
	delete[] _allocator;
	return;
}

#endif 