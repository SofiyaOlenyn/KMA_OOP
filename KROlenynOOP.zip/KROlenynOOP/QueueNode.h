#pragma once
#ifndef U_QUEUENODE_H
#define U_QUEUENODE_H
#include "Queue.h";
#include <assert.h>
#include <string>
#include <iostream>
using namespace std;
template <class T>
struct Node
{
	T _value;
	Node<T>* _allocate;
};
template <class T>
class QueueNode :  public Queue<T>
{
public:


	class BadQueueNode;

	

	QueueNode();
	
	~QueueNode();
	


	//through that the list is endless so capacity() == size ()

	int capacity() const { return _count; }

	int size() const { return _count; }

	bool empty() const;
	
	bool full() const;
	
	const T& front() const;
	
	
	void put (const T& qE);
	
	void pop();
	
private: 
	int _count;

	Node<T>* _front; 
	Node<T>* _back;

	const QueueNode<T>& operator=(const QueueNode<T>&) = delete;

	QueueNode(const QueueNode<T>&) = delete;
};

	template <class T>
	bool QueueNode<T>::empty() const
{
	return (_front == nullptr);
} 
template <class T>
bool QueueNode<T>::full() const
{
	return false;
}

template <class T>
const T& QueueNode<T>::front() const
{
	assert(_front != nullptr);
	return _front->_value;
}
template <class T>
void QueueNode<T>::put(const T& value)
{
	_count++;
	Node<T>* temp;

	temp = new Node<T>; 

	temp->_value = value;

	temp->_allocate = nullptr;

	if (_front == nullptr) 
	{
		_front = temp;
		_back = temp;
	}
	else 
	{
		_back->_allocate = temp;

		_back = _back->_allocate;
	}
}
template <class T>
void QueueNode<T>::pop()
{
	Node<T>* temp;

		if (!empty())
		{
		_count--;
		temp = _front; 
		_front = _front->_allocate; 
		delete temp; 

		if (_front == nullptr) 
		
			_back = nullptr; 
	}
	else
		throw BadQueueNode("Empty array");
}
template<class T>
QueueNode<T>::QueueNode():_count(0)
{

	
	
	 Node<T>* temp;
	while (_front != nullptr) 
	{
		 temp = _front; 
		_front = _front->_allocate; 
		delete temp; 
	}
	_back = nullptr; 
}

template<class T>
QueueNode<T>::~QueueNode() {

	delete[]_back;
	delete[]_front;

	return;
}

template<class T>
class QueueNode<T>::BadQueueNode
{
public:
	BadQueueNode(string s) :
		_trouble(s) {};
	const string& getTrouble() const
	{
		return _trouble;
	}
private:
	string _trouble;
};
#endif