#include <iostream>
#include "Queue.h"
#include "QueueNode.h"
#include "QueueArray.h"

using namespace std;

/*KR Olenyn Sofiya group �2 */

int main()

{
	
	try {
		cout << "-------------------------TEST QUEUEARRAY---------------------------" << endl;
		cout << "---------Test for <int> -------" << endl;
		QueueArray<int> queue1;
		cout << "---------QueueArray<int> queue1 -------" << endl;
		cout << "Cheak if it is empty: " << queue1.empty() << endl;
		cout << "Cheak capacity: " << queue1.capacity() << endl;
		cout << "Cheak size : " << queue1.size();
		cout << "Put new elements: 5, 34, 1001" << endl;

		queue1.put(5);
		queue1.put(34);
		queue1.put(101);

		cout << "Cheak size : " << queue1.size() << endl;
		cout << "Cheak if it is empty: " << queue1.empty() << endl;
		cout << "Cheak if it is full: " << queue1.full() << endl;
		cout << "The first element is: " << queue1.front() << endl;
		cout << "Pop element from the queue!" << endl;
		queue1.pop();
		cout << "Cheak size : " << queue1.size() << endl;
	}
	catch (QueueArray<int>::BadQueueArray& e) {
		cout<<e.getTrouble();
	}
	try {
		cout << "---------Test for <string> -------" << endl;
		QueueArray<string> queue6(5);
		cout << "---------QueueArray<char> string(5) -------" << endl;
		cout << "Cheak if it is empty: " << queue6.empty() << endl;
		cout << "Cheak capacity: " << queue6.capacity() << endl;
		cout << "Cheak size : " << queue6.size() << endl;
		cout << "Put new elements: 'Olenyn' , 'Sofiya' , 'Igorivna', 'i' , 'jjjjj' " << endl;

		queue6.put("Olenyn");
		queue6.put("Sofiya");
		queue6.put("Igorivna");
		queue6.put("jjjjj");

		cout << "Cheak size : " << queue6.size() << endl;
		cout << "Cheak if it is empty: " << queue6.empty() << endl;
		cout << "Cheak if it is full: " << queue6.full() << endl;
		cout << "The first element is: " << queue6.front() << endl;
		cout << "Pop element from the queue!" << endl;
		queue6.pop();
		cout << "Cheak size : " << queue6.size() << endl;
	}
	catch (QueueArray<string>::BadQueueArray& e) {
		cout << e.getTrouble();
	}
	try {
		cout << "---------Test for <char> -------" << endl;
		QueueArray<char> queue2(5);
		cout << "---------QueueArray<char> queue2(5) -------" << endl;
		cout << "Cheak if it is empty: " << queue2.empty() << endl;
		cout << "Cheak capacity: " << queue2.capacity() << endl;
		cout << "Cheak size : " << queue2.size() << endl;
		cout << "Put new elements: 's' , 'o' , 'i', 'i' , 'j' " << endl;

		queue2.put('s');
		queue2.put('o');
		queue2.put('i');
		queue2.put('i');
		queue2.put('j');

		cout << "Cheak size : " << queue2.size() << endl;
		cout << "Cheak if it is empty: " << queue2.empty() << endl;
		cout << "Cheak if it is full: " << queue2.full() << endl;
		cout << "The first element is: " << queue2.front() << endl;
		cout << "Pop element from the queue!" << endl;
		queue2.pop();
		cout << "Cheak size : " << queue2.size() << endl;
	}
	catch (QueueArray<char>::BadQueueArray& e) {
		cout << e.getTrouble();
	}
	
	cout << "-------------------------TEST QUEUENODE---------------------------" << endl;
	try {
		cout << "---------Test for <int> -------" << endl;
		QueueNode<int> queue3;
		cout << "---------QueueNode<int> queue3 -------" << endl;
		cout << "Cheak if it is empty: " << queue3.empty() << endl;
		cout << "Cheak capacity: " << queue3.capacity() << endl;
		cout << "Cheak size : " << queue3.size() << endl;
		cout << "Put new elements: 5, 34, 1001" << endl;

		queue3.put(5);
		queue3.put(34);
		queue3.put(101);

		cout << "Cheak size : " << queue3.size();
		cout << "Cheak if it is empty: " << queue3.empty() << endl;
		cout << "Cheak if it is full: " << queue3.full() << endl;
		cout << "The first element is: " << queue3.front() << endl;
		cout << "Pop element from the queue!" << endl;
		queue3.pop();
		cout << "Cheak size : " << queue3.size() << endl;
	}
	catch (QueueNode<int>::BadQueueNode& e) {
		cout << e.getTrouble();
	}
	try {
		cout << "---------Test for <char> -------" << endl;
		QueueNode<char> queue4;
		cout << "---------QueueNode<char> queue4 -------" << endl;
		cout << "Cheak if it is empty: " << queue4.empty() << endl;
		cout << "Cheak capacity: " << queue4.capacity() << endl;
		cout << "Cheak size : " << queue4.size() << endl;
		cout << "Put new elements: 's' , 'o' , 'i', 'i' , 'j' " << endl;

		queue4.put('s');
		queue4.put('o');
		queue4.put('i');
		queue4.put('i');
		queue4.put('j');

		cout << "Cheak size : " << queue4.size() << endl;
		cout << "Cheak if it is empty: " << queue4.empty() << endl;
		cout << "Cheak if it is full: " << queue4.full() << endl;
		cout << "The first element is: " << queue4.front() << endl;
		cout << "Pop element from the queue!" << endl;
		queue4.pop();
		cout << "Cheak size : " << queue4.size() << endl;
	}
	catch (QueueNode<char>::BadQueueNode& e) {
		cout << e.getTrouble();
	}
	


	
	system("pause");
	return 0;
}