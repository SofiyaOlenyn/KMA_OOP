#include "Point.h"
#include <iostream>
using namespace std;

int main()
{
	Point P1, P2(2,2);
    cout << "Amount of points: " << P2.amount() << endl;
	Point P3(P1);
	cout << "Amount of points: " << P3.amount() << endl;
	P1.~Point();
	cout << "Amount of points: " << P3.amount() << endl;
	cout << "P2=" << P2 << endl;
	cout << "P3=P2  " << endl;
	P3 = P2;
	cout << "P3=" << P3 << endl;
	cout << "P4=P2+P3  " << endl;
	Point P4 = P2 + P3;
	cout << " P4=" << P4 << endl;
	cout << "Amount of points: " << P2.amount() << endl;
	cout << "P4=" << P4 << "  P2=" << P2 << endl;
	cout << "P4+=P2 " << endl;
	P4 += P2;
	cout<<"P4=" << P4 	<< "   P3=" << P3 <<   "      P2=" << P2 << endl;
	cout << "P4==P2?    " << (P4==P2) << endl;
	cout << "P4!=P2?    " << (P4!=P2) << endl;
	cout << "P3==P2?    " << (P3 == P2) << endl;
	cout << "P3!=P2?    " << (P3 != P2) << endl;

	system("pause");
	return 0;
}