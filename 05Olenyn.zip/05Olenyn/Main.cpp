#include <iostream>
#include "Data.h"

using namespace std;

int main()
{
	
	
	try
	{
		cout << "--Default date: ";
		Date::showDefault();
		cout << endl;
		
		cout << "--Set new default date: " << endl;
		Date::setDefault(1, Date::Month(1), 2007);
		cout << "--Default new date: ";
		Date::showDefault();

		
		cout << "--Create new Date: " << endl;
		Date d, d1(14, 9, 2001), d2(d1);



		cout << "---Test getters: " << endl;
		cout << "Get day " << d1.day()<< endl;
		cout << "Get month name " << d1.getMonthName() << "    Get month number " << d1.month()<<  endl;
		cout << "Get year " << d1.year() << endl;



		cout << "---Try to set bad data : " << endl;
		Date x(48, 14, 2008);
	}
	catch (Date::BadDate bd)
	{
		cerr << "!!Bad date: " << bd << endl;
	}

	try
	{
	
		cout << "-----Test prefix operators----- "  << endl;
		Date d1(1, 1, 1991);
		cout << "Date before decrement: " << d1 << endl;
		--d1;
		cout << "Date after decrement: " << d1 << endl;

		
		cout << "--Date of leap year: " << endl;
		Date d2(28, 2, 2020);
		cout << "Date before increment: " << d2;
		++d2;
		cout << "Date after increment: " << d2;
		cout << "--Date of no leap year: " << endl;
		Date d3(28, 2, 2019);
		cout << "Date before increment: " << d3;
		++d3;
		cout << "Date after increment: " << d3;

		
		
		
		cout << "-----Test postfix operators----- " << endl;
		cout << "Date before increment: " << d2;
		d2++;
		cout << "Date after increment: " << d2;
		cout << endl;
		cout << "Date before decrement: " << d2;
		d2--;
		cout << "Date after decrement: " << d2;




		cout << "-----Test setters----- " << endl;
		cout << "Date before tasting setters: " << d2;

		d2.setDay(6);
		cout << endl;
		cout << "Set day 6:   " << d2;
		d2.setMonth(6);
		cout << endl;
		cout << "Set month JUN:   " << d2;
		d2.setYear(2001);
		cout << endl;
		cout << "Set year 2001:    " << d2;
		cout << endl;
		cout << "  Date: " << d2;

		
	}
	catch (Date::BadDate bd)
	{
		cerr << "!!Bad date: " << bd << endl;
	}
	try {
		Date d2(31, 1, 2010);
		cout << endl;
		cout << "-----Test when we set wrong day:  Set day - 45" << endl;
		d2.setDay(45);
	}
	catch (Date::BadDate bd)
	{
		cerr << "!!Bad date: " << bd << endl;
	}
	try {
		Date d2(31, 1, 2010);
		cout << endl;
		cout << "-----Test when we set wrong month:  Set month - 15" << endl;
		d2.setMonth(15);
	}
	catch (Date::BadDate bd)
	{
		cerr << "!!Bad date: " << bd << endl;
	}
	try {
		Date d2(31, 1, 2010);
		cout << endl;
		cout << "-----Test when we set wrong year:  Set year -  -5" << endl;
		d2.setYear(-5);
	}
	catch (Date::BadDate bd)
	{
		cerr << "!!Bad date: " << bd << endl;
	}
	
	system("pause");
	
	return 0;
}
