#include "Time.h";
#include <iostream>
//#define NDEBUG
const double Time::hourToDec = 1 / 3600;

void Time::normalizeTime()
{

	_hours += ((_minutes + (_seconds / 60)) / 60);
	_minutes = (_minutes + (_seconds / 60)) % 60;
	_seconds %= 60;


}
Time::Time(int s , int m , int h):_seconds(s), _minutes(m), _hours(h)  {

#ifndef NDEBUG
	cout << "Time created: " << *this << endl;
#endif
	normalizeTime();
	
}

Time::Time(const Time& t)  : _seconds(t._seconds), _minutes(t.minutes()), _hours(t.hours()) {

#ifndef NDEBUG
	cout << "Time created: " << *this << endl;
#endif
	normalizeTime();
}



Time& Time::operator=(const Time& t) {
	_hours = t.hours();
	_minutes = t.minutes();
	_seconds = t.seconds();  
	return *this;
}
//��� ����� � ������
Time::operator int() const {
	return  hours() * 3600 + minutes() * 60 + seconds()  ;
}

Time::operator double() const
{
	return static_cast<double>(seconds()) / 3600  + (static_cast<double>(minutes()) / 60) + hours();
}
const Time& Time::operator++() {

	seconds() += 1;
	normalizeTime();
	return *this;
}

const Time Time::operator++(int)
{
	const Time t(*this);
	seconds() += 1;
	normalizeTime();
	return t;
}

const Time& Time::operator--()
{
	const int t (static_cast<int>(*this));

		_hours = 0;
		_minutes = 0;
		_seconds = t - 1;

	normalizeTime();
	return *this;
}

const Time Time::operator--(int)
{
	const Time t(*this);
	const int t1 = static_cast<int>(*this);
	
		hours() = 0;
		minutes() = 0;
		seconds() = t1 - 1;
	
	normalizeTime();
	return t;
}

double operator + (const Time& t1, const Time& t2)
{
	return int(t1) * Time::hourToDec + int(t2) * Time::hourToDec;

}



ostream& operator<<(ostream& os, const Time& t)
{
	return os << t.hours() << ":" << t.minutes() << ":" << t.seconds() << endl;
}

// ������������
void Time::setHours(const unsigned int h) {
	_hours = h; normalizeTime();
	return;
}

void Time::setMinutes(const unsigned int m) {
	_minutes = m; normalizeTime();
	return;
}

void Time::setSeconds(const unsigned int s) {
	_seconds = s; normalizeTime();
	return;
}


