#pragma once
#include <iostream>
#include "Data.h"
#include "Time.h"
using namespace std;

class Timer
{
private:
	Date _aDate;

	Time _aTime;

	Time _diapazon;

public:
	Timer(const Date& d, const Time& t, const Time& di): _aDate(d),	_aTime(t),_diapazon(di){}

	Timer(const int d, const int m, const int y, const int s, const int mi, const int h, const int dS, const int dM, const int dH) :

		_aDate(d, m, y), _aTime(s, mi, h), _diapazon(dS, dM, dH)
	{
	}

	~Timer()
	{
	}
	Date aDate() const
	{
		return _aDate;
	}

	Date& aDate()
	{
		return _aDate;
	}

	void setADate(const Date& a)
	{
		_aDate = a;
	}

	Time aTime() const
	{
		return _aTime;
	}

	Time& aTime()
	{
		return _aTime;
	}

	void setATime(const Time& time)
	{
		_aTime = time;
	}

	Time diapazon() const
	{
		return _diapazon;
	}

	Time& diapazon()
	{
		return _diapazon;
	}

	void setDiapazon(const Time& t)
	{
		_diapazon = t;
	}


	void startAlarm();

	static long difference(Date& d1, Date& d2, Time& t1, Time& t2);

};
