#include <iostream>
#include  "Timer.h"
#include  "Data.h"
#include "Time.h"
#include <thread>
using namespace std;



void runInThread()
{
	try {
		/* !!!!!!!!   to test timer you have to fill in time bellow in format  SEC-MIN-HOUR !!!!!! */
		const Time startTime(50, 13, 16);
		const Time interval(0, 1, 0);
		const Date startDate(4, 3, 2020);
		/* !!!!!!!!   to test timer you also to fill in data bellow */
		Timer timer(startDate, startTime, interval);

		timer.startAlarm();
	}
	catch (Date::BadDate& e)
	{
		cout << e << endl;
	}
}


int main()
{
	try {
	
		{
			cout << "------------" << endl;
			cout << "Simple constructor : " << endl;
			cout << "t1: " ;
			Time t1(9, 37, 20);
			cout << "t2: "; 
			Time t2;
			cout << "Copy constructor :  t3(t1) " << endl;
			Time t3(t1); 
			cout << "Assigment operator :  t4=t1" << endl;
			Time t4 = t1;     


			cout << "Convert time to seconds" << endl;
			cout << t1.operator int() << endl;     
			cout << "Convert time to hours" << endl;
			cout << t1.operator double() << endl << endl;

			cout << "Test getters" << endl;
			cout << t1 << endl;
			cout << "Hours: " << t1.hours()<< endl;
			cout << "Minuts: " << t1.minutes() << endl;
			cout << "Seconds: " << t1.seconds() << endl;
			cout << "Test setters" << endl;
			cout << "Hours = 2, Minuts = 2, Seconds = 2: ";
			
			t2.setHours(2);
			t2.setMinutes(2);
			t2.setSeconds(2);
			cout << t2 << endl;
			cout << "Time before changes: " << t1;
			cout << "---Time after prefix increment: ";
			cout<< (++t1) << endl;
			 (t1++);
			 cout << "---Time after postfix increment: ";
			 cout << t1;

			cout << "Time before changes: " << t1;
			(t1--);
			cout << "---Time after postfix deccrement: ";
			cout << t1 << endl;
			cout << "---Time after prefix decrement: " << --t1;
			

			
			

		}

	
		{
			cout << "TIMER" << endl;
		
			std::thread first(runInThread);
			cout << "We have created new Alarm clock: ";
			first.join();
			
		}
	}
	catch (Date::BadDate& e)
	{
		cout << e << endl;
	}
	system("pause");
	return 0;
}