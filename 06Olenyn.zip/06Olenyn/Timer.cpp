#define _CRT_SECURE_NO_WARNINGS
#include "Timer.h"
#include <ctime>
#include <thread>
using namespace std;

void Timer::startAlarm()
{

	time_t timer;





	time(&timer);
	

	struct tm* today = gmtime(&timer);

	long time = 0;


	Time currentTime(today->tm_sec, today->tm_min, today->tm_hour + 2);


	Date currentDate(today->tm_mday, ++(today->tm_mon), today->tm_year += 1900);

	


	cout << "Current time is: " << currentTime;




	try
	{

		time = difference(currentDate, _aDate, currentTime, _aTime);

	}
	catch (const char* e)
	{

		cout << e << endl;
	     return;

	}



	cout << "!  Alarm is created ! " << endl;

	std::this_thread::sleep_for(std::chrono::seconds(static_cast<int>(_diapazon)));
	cout << "!!!    alarm   !!!!" << endl;

}

long Timer::difference(Date& d1, Date& d2, Time& t1, Time& t2)
{
	if (d2 < d1)
		throw "BAD date input";


	Date temp(d1);
	long secDifference = 0;

	if (d2 == temp)
	{
		if (t2 < t1)
			throw "BAD time input";

		secDifference += static_cast<int>(t2) - static_cast<int>(t1);

		return secDifference;
	}
	else {


		while (d2 != temp)
		{
			secDifference += 86400;
			++temp;
		}

		secDifference -= 86400;

		secDifference += (86400 - static_cast<int>(t1)) + static_cast<int>(t2);

		return  secDifference;
	}
}
