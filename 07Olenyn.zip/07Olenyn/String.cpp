﻿#define _CRT_SECURE_NO_WARNINGS
#include "String.h"
#include <utility>
#include <string>
#include <iostream>


String::String() : _len(0), _allocator(new char[1])
{
	_allocator[0] = '\0';
	return;
}
String::String(const char*  p) {
	if (p == nullptr)
	{
		throw BadString("!!!Attempt to use not defined constructor!!!");
	}
	_len = strlen(p);
	_allocator = new char[_len + 1];
	strcpy(_allocator, p);
	return;
}



String::String(const char ch) : _len(1), _allocator(new char[2])
{
	_allocator[0] = ch;
	_allocator[1] = '\0';
	return;
}

String::String(const string&  st):_len(st.length()), _allocator(new char[st.length() + 1])
{
	strcpy(_allocator, st.c_str());
	return;
};

String::~String()
{
	delete[] _allocator;
	_allocator = nullptr;

};
const string String::STL_string() const
{
	return string(_allocator);
}

String::String(const String& s, int multiplayer):
	_len(s._len* multiplayer),

	_allocator(new char [_len+1]) { 
	
	char* target=_allocator;   
	for(int i=0; i<multiplayer; i++) {  
	strcpy(target, s._allocator);
	 
	target+=s._len; 
	
	}   
	return;



}

String& String::operator=(const String& s)
{
	if (this == &s) 
		return *this;
	
	delete[] _allocator; 
	_len = s._len; 
	_allocator = new char[_len + 1]; 
	strcpy(_allocator, s._allocator); 
	return *this;
}

String& String::operator=(const string& s)
{
	const String temp_string(s);
	return (*this = temp_string);
}
String& String::operator=(const char* ch) {

	if (ch == 0)               
		return *this;              
	delete [] _allocator;        
	for(_len=0; ch[_len]; _len++); 
	_allocator=new char[_len+1];  
	strcpy(_allocator, ch);     
	return *this;
}
String& String::operator=(const char ch) {

	delete[] _allocator;  
	_len=1;            
	
	_allocator=new char[2]; 
	_allocator[0]=ch;      
	_allocator[1]='\0';    return *this; 

}



void String::clear()
{
	delete[] _allocator;
	_len = 0;
	_allocator = new char[1];
	_allocator[0] = '\0';
}

char& String::operator[](size_t i) {
	if (_len <= i)
		throw BadIndex(i);
	return _allocator[i];
};

const char  String::operator[](size_t i) const {
	if (_len <= i) throw BadIndex( i);    return _allocator[i];
}




bool String::operator != (const String& s) const{
	return !(*this == s);
}


bool  String::operator < (const String& s) const {
	bool res = true; int i = 0; 

	while(res&&(i<_len)&&(i<s._len))
	{     
		res=res&&(*(_allocator+i)==*(s._allocator+i));
		i++;    
	} 

		if (res) return _len < s._len; i--;
		
		return *(_allocator+i)<*(s._allocator+i); 
}

bool  String::operator <= (const String& s) const {
	if (*this == s) return true;    return *this < s;
}

bool  String::operator > (const String& s) const {

	return !(*this <= s);
}

bool  String::operator >= (const String& s) const {
	if (*this == s) return true;    return *this > s;
}
String String::operator+(const String& s) const{
	String res(*this);
	return res += s;
} 

String& String::operator+=(const char* ps) {
	if (ps == nullptr) return *this; 
	
	size_t len = strlen(ps); 

	char* newAllocator = new char[len + _len + 1]; 
	strcpy(newAllocator, _allocator); 
	delete[] _allocator; 
	_allocator = newAllocator; 
	strcpy(_allocator + _len, ps); 
	_len += len; 
	return *this;
}

String& String::operator+=(const String& s) {

	char* tempal = new char[s._len + 1];
	strcpy_s(tempal, s._len + 1, s._allocator);

	const size_t len = _len + s._len; 
	
	char* newAllocator = new char[len + 1]; 
	strcpy(newAllocator, _allocator);

	delete[] _allocator; 
	_allocator = newAllocator;
	strcpy(_allocator + _len, tempal); 

	_len = len; 

	delete[] tempal;
	tempal = nullptr;

	return *this;
}

String& String::operator+=(const string& s) {
	const String tempS(s);
	return (*this += tempS);
}
ostream& operator<<(ostream& os, const String& s)
{
	for (size_t i = 0; i < s.length(); i++) os << s[i];
	return os;
}
//утиліти для порівнння рядків наших і STL

bool  operator == (const String& s1, const String& s2)
{
	bool equal = s1.length() == s2.length(); 
	for (int i = 0; (i < s1.length()) && equal; i++)    
		equal = *(s1.c_str() + i) == *(s2.c_str() + i);
	return equal;
} 
bool operator == (const String& s1, const string& s2) {
	return (s1.STL_string()) == s2;
}
bool operator == (const string& s1, const String& s2) {
	return s2 == s1;

}
bool operator != (const String& s1, const string& s2) {
	return !(s1 == s2);
}
bool operator != (const string& s1, const String& s2) {
	return !(s1 == s2);
}
bool operator <(const String& s1, const string& s2) {
	return (s1.STL_string()) < s2;

}
bool operator <(const string& s1, const String& s2) {
	return s1 < (s2.STL_string());

}
bool operator <=(const String& s1, const string& s2) {
	return (s1.STL_string()) <= s2;

}
bool operator <=(const string& s1, const String& s2) {
	return s1 <= (s2.STL_string());

}
bool operator >(const String& s1, const string& s2) {
	return (s1.STL_string()) > s2;

}
bool operator >(const string& s1, const String& s2) {
	return s1 > (s2.STL_string());

}
bool operator >=(const String& s1, const string& s2) {
	return (s1.STL_string()) >= s2;

}
bool operator >=(const string& s1, const String& s2) {
	return s1 >= (s2.STL_string());

}
String operator +(const String& s1, const string& s2) {
	return (s1 + String(s2));

}
String operator +(const string& s1, const String& s2) {
	return (String(s1) + s2);

}