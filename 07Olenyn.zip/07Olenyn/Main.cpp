#include <iostream>
#include <string>
#include "String.h"
using namespace std;

int main()
{



	

	cout << "------------- Test constructors--------------\n";
	
	cout << "---String()---"<<endl;
	
	cout<<String() << endl;
	cout << "---String(const char*)---" << endl;
	const char* ch1 = "char*";
	cout << "Const char* ch1 :   " <<ch1<< endl;
	String S2(ch1);

	cout << "String S2(ch1):   "<<S2 << endl;
	cout << endl;

	const char* np = nullptr;
	try
	{
		cout << "const char* np = nullptr " << endl;

		cout << "String(np)" << endl;
		String d(np);
	}
	catch (String::BadString& e)
	{
		e.diagnose();
	}
	
	cout << endl;
	cout << "---String(const char)---" << endl;
	const char ch2 = 'c';
	cout << "Const char  ch2 :   " << ch2 << endl;
	String S3(ch2);
	cout << "String S3(ch2):   " << S3 << endl;
	cout << endl;
	cout << "---String(const string&)---" << endl;
	const string s4 = "string&";
	cout << "Const string&  s4:   " << s4 << endl;
	String S4(s4);
	cout << "String S4(s4):   " << S4 << endl;
	cout << endl;
	cout << "---String(const String& s, int multiplayer );---" << endl;
	int mul (4);
	cout << "multiplayer = 4, String = S4   " << endl;
	String S5(S4, mul);
	cout << "String S5(S4, multiplayer):   " << S5 << endl;
	cout << endl;
	

	cout << "------------- Test assigment operators--------------\n";

	cout << "---String& operator=(const String&)---" << endl;
	cout << "S2:   " << S2 << "     S3:   " << S3 << endl;
	 S3=S2;
	cout << "S3=S2:   " << S3 << endl;
	cout << endl;
	cout << "---String& operator=(const string&)---" << endl;
	string s6 = "I love programming";
	cout << "S3:   " << S3 << "     s6:   " << s6 << endl;
	S3 = s6;
	cout << "S3=s6:   " << S3 << endl;
	cout << endl;
	cout << "---String& operator=(const char*)---" << endl;
	const char* ch3 = "bla bla bla";
	cout << "S2:   " << S2 << "     ch3:   " << ch3 << endl;
	S2 = ch3;
	cout << "S2=ch3:   " << S2 << endl;
	cout << endl;
	cout << "---String& operator=(const char*)---" << endl;
	
	cout << "S2:   " << S2 << "     ch2:   " << ch2 << endl;
	S2 = ch2;
	cout << "S2=ch2:   " << S2 << endl;
	cout << endl;

	cout << "------------- Test other --------------\n";
	cout << "--- STL_string()---" << endl;

	cout << "S3:   " << S3 << endl;

	cout << "S3.STL_string():" << (S3.STL_string()) << endl;
	cout << endl;
	cout << "---c_str()---" << endl;

	cout << "S3:   " << S3 << endl;

	cout << "S3.c_str():" << (S3.c_str()) << endl;
	cout << endl;
	cout << "---length()---" << endl;

	cout << "S3:   " << S3 << endl;

	cout << "S3.length():" << (S3.length()) << endl;
	cout << endl;
	cout << "---empty()---" << endl;

	cout << "S3:   " << S3 << endl;

	cout << "S3.empty():" << (S3.empty()) << endl;
	cout << endl;
	cout << "---clear()---" << endl;

	cout << "S2:   " << S2 << endl;
	S2.clear();
	cout << "S2.clear()    S2:" << S2<< endl;
	cout << endl;
	cout << "------------- Test operators[] --------------\n";
	cout << S3<< endl;
	try
	{
		cout << " S3[-1]: ";
		cout << S3[-1];
		cout << endl;
	}
	catch (String::BadIndex& e)
	{
		e.diagnose();
	}

	try
	{
		cout << " S3[4]";
		cout<< S3[4];
		cout << endl;
	}
	catch (String::BadIndex& e)
	{
		e.diagnose();
	}

	try
	{
		cout << " S3[-1]";
		cout << S3[-1];
		cout << endl;
	}
	catch (String::BadIndex& e)
	{
		e.diagnose();
	}

	try
	{
		cout << " S3[3]";
		cout << S3[3];
		cout << endl;
	}
	catch (String::BadIndex& e)
	{
		e.diagnose();
	}
	
	

	cout << "------------- Test operators--------------\n";
	const string ss4 = " very much";
	String SS(ss4);
	const char* ch5 = " !!!! ";
	
	cout << "SS: " << SS << "    S3: " << S3 <<  "    ch5: " << ch5<<endl;
	cout << "SS==S3  " << (SS == S3) << endl;
	cout << "SS!=S3  " << (SS != S3) << endl;
	cout << "SS>S3  " << (SS > S3) << endl;
	cout << "SS>=S3  " << (SS >= S3) << endl;
	cout << "SS<S3  " << (SS < S3) << endl;
	cout << "S3<=S3  " << (S3 <= S3) << endl;
	cout << "S3+SS  " << (S3 + SS) << endl;

	cout << "S3+=SS  " << (S3 += SS) << endl;
	cout << "S3+=ss4  " << (S3 += ss4) << endl;
	
	cout << "S3+=ch5  " << (S3 += ch5) << endl;

	cout << "------------- Test operators for mixed types--------------\n";
	String S11(ch5);
	cout << "String S3: " << S3 << endl << "   String S11: " << S11 << endl << "string    ss4: " << ss4 << endl << "const char*   ch5: " << ch5 << endl;
	cout << "S3==ss4 " << (S3 == ss4) << endl;
	cout << "ss==S3  " << (ss4 ==S3) << endl;
	cout << "S11==ch5 " << (S11 == ch5) << endl;
	cout << "S11>=ss4  " << (S11 >= ss4) << endl;
	cout << "S11<ss4  " << (S11 < ss4) << endl;
	cout << "S3<=ch5  " << (S3 <= ch5) << endl;
	cout << "S3+ch5  " << (S3 + ch5) << endl;
	cout << "ss4+S3  " << (ss4 + S3) << endl;
	S2.~String();
	S3.~String();
	S4.~String();
	S5.~String();
	SS.~String();
	S11.~String();
	system("pause");
	return 0;
}
