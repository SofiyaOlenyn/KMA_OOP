#include "Screen.h"
#include <iostream>
using namespace std;

int main()
{
	{
		cout << "----TEST1----" << endl;
		Screen s1(10, 15);
		cout << "----Show S1 (empty screen)----" << endl;
		s1.show();
		cout << endl;
		Screen s2(20, 20, "I love programming !");
		cout << " -----Show S2:-----" << endl;
		s2.show();
		cout << endl;
		cout << "-----Move and get for 20 times:-----" << endl << endl;

		for (int i = 0; i < 20; i++)
		{
			s2.move();
			cout << s2.get() << endl;
		}
		cout << "-----Back and get for 20 times:------" << endl << endl;

		for (int i = 0; i < 20; i++)
		{
			s2.back();
			cout << s2.get() << endl;
		}
		cout << endl;
		cout << "------S2 home():-----" << s2.home() << endl;
		cout << "------S2 showCurrent():-----" <<  endl;
		s2.showCurrent();
		cout << endl;
		cout << "------S2 move(1,10):-----"  << endl;
		s2.move(1, 10).showCurrent();
		cout << endl;
		cout << "----set(*)----- " <<
		s2.set('*').get() << endl;
		s2.show();
		cout << "------S2   clear:-----" << endl;
		s2.clear();
		s2.show();
		cout << endl;
		cout << endl;
		
	}

	{
		cout << "----TEST2----" << endl;
		
		
		cout << endl;
		Screen s3(5, 5, "blablabla");
		cout << " -----Show S3:-----" << endl;
		s3.show();
		cout << endl;
		cout << "-----Move and get for 10 times:-----" << endl << endl;

		for (int i = 0; i < 10; i++)
		{
			s3.move();
			cout << s3.get() << endl;
		}
		cout << "-----Back and get for 5 times:------" << endl << endl;

		for (int i = 0; i < 5; i++)
		{
			s3.back();
			cout << s3.get() << endl;
		}
		cout << endl;
		cout << "------S3 home():-----" << s3.home() << endl;
		cout << "------S3 showCurrent():-----" << endl;
		s3.showCurrent();
		cout << endl;
		cout << "------S3 move(2,4):-----" << endl;
		s3.move(2, 4).showCurrent();
		cout << endl;
		cout << "----set(*)----- " <<
			s3.set('*').get() << endl;
		s3.show();
		cout << "------S3  clear:-----" << endl;
		s3.clear();
		s3.show();
	
	}
	
system("pause");
	return 0;
}
