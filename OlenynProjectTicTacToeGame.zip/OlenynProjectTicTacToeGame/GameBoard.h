#ifndef BOARD_H
#define BOARD_H

using namespace std;

class GameBoard
{
private:
			bool working; 
public:

	
		GameBoard(bool d = false)
	{
		working = d;
	}
		~GameBoard() {};
	
	bool getDraw();
	void drawingBoard(bool);

	void updatingBoard(char[3][3], int, int, bool);
	
	
	void showingBoard(char[3][3]);
	bool checkWinning(char[3][3], bool);

	bool checkDraw(char[3][3]);
	void clearingBoard(char[3][3]);
	
};

#endif
