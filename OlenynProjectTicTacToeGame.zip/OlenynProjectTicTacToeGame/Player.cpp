

#include <cstdlib>
#include <iostream>
#include "Player.h"

using namespace std;



bool Player::playersStep()
{
	char input;
	do
	{
		cout << "Press S to start the game !!!!!" << endl;
		cin >> input;
		cout << "P.S. Row and columns are within 1-3 !!! " << endl;
		if (input == 'S' or input == 's')
			return true;

	} while (input != 'S' && input != 's');
}




void Player::stepsOfPlayer(char board[3][3], int& row, int& col)
{

	bool repeat = true;
	do
	{
		do
		{
			cout << "Enter the cordinats where you want to go." << endl;
		
			cout << "Row: " << endl;
			cin >> row;
			cout << "Column: " << endl;
			cin >> col;
			row = row - 1;
			col = col - 1;
		} while (row < 0 && row > 4 && col < 0 && col > 4);

		if (board[row][col] != '-')
			cout << "That place is already taken. Try again!" << endl;
		else
			repeat = false;
	} while (repeat == true);
}


void Player::stepsOfComputer(char board[3][3], int& row, int& col)
{
	do
	{
		row = (rand() % 3);
		col = (rand() % 3);

	} while (board[row][col] != '-');
}

