#ifndef PLAYER_H
#define PLAYER_H

using namespace std;

class Player
{
private:

public:
	
	bool playersStep();
	~Player() {};
	void stepsOfComputer(char[3][3], int&, int&);
	void stepsOfPlayer(char[3][3], int&, int&);
	
};
#endif
