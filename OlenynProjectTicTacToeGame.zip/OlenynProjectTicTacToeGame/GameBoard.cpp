#include <cstdlib>
#include <iostream>
#include "GameBoard.h"

using namespace std;

bool GameBoard::getDraw()
{
	return working;
}

void GameBoard::drawingBoard(bool d)
{
	working = d;
}


void GameBoard::clearingBoard(char b[3][3])
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
			b[i][j] = '-';
	}
}


void GameBoard::updatingBoard(char b[3][3], int r, int c, bool player)
{
	cout << endl;

	if (player == true)
	{
		b[r][c] = 'X';
	}
	else
	{
		b[r][c] = 'O';
	}
}






bool GameBoard::checkWinning(char b[3][3], bool player)
{
	if (player == true)
	{
		if (b[0][0] == 'X' && b[0][1] == 'X' && b[0][2] == 'X')
			return true;
		if (b[1][0] == 'X' && b[1][1] == 'X' && b[1][2] == 'X')
			return true;
		if (b[2][0] == 'X' && b[2][1] == 'X' && b[2][2] == 'X')
			return true;

		if (b[0][0] == 'X' && b[1][0] == 'X' && b[2][0] == 'X')
			return true;
		if (b[1][1] == 'X' && b[1][1] == 'X' && b[2][1] == 'X')
			return true;
		if (b[0][2] == 'X' && b[1][2] == 'X' && b[2][2] == 'X')
			return true;

		if (b[0][0] == 'X' && b[1][2] == 'X' && b[2][2] == 'X')
			return true;
		if (b[0][2] == 'X' && b[1][1] == 'X' && b[2][0] == 'X')
			return true;
		else
			return false;
	}

	if (player == false)
	{
		if (b[0][0] == 'O' && b[0][1] == 'O' && b[0][2] == 'O')
			return true;
		if (b[1][0] == 'O' && b[1][1] == 'O' && b[1][2] == 'O')
			return true;
		if (b[2][0] == 'O' && b[2][1] == 'O' && b[2][2] == 'O')
			return true;

		if (b[0][0] == 'O' && b[1][0] == 'O' && b[2][0] == 'O')
			return true;
		if (b[0][1] == 'O' && b[1][1] == 'O' && b[2][1] == 'O')
			return true;
		if (b[0][2] == 'O' && b[1][2] == 'O' && b[2][2] == 'O')
			return true;

		if (b[0][0] == 'O' && b[1][1] == 'O' && b[2][2] == 'O')
			return true;
		if (b[0][2] == 'O' && b[1][1] == 'O' && b[2][0] == 'O')
			return true;
		else
			return false;
	}
}

bool GameBoard::checkDraw(char b[3][3])
{
	if (b[0][0] != '-' && b[0][1] != '-' && b[0][2] != '-' &&
		b[1][0] != '-' && b[1][1] != '-' && b[1][2] != '-' &&
		b[2][0] != '-' && b[2][1] != '-' && b[2][2] != '-')
		return true;
	else
		return false;
}



void GameBoard::showingBoard(char b[3][3])
{
	cout << endl;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
			cout << b[i][j];
		cout << endl;
	}
}



