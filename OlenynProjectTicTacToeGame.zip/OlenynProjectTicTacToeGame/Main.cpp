#include <cstdlib>
#include <iostream>
#include "Player.h"
#include "GameBoard.h"
#include <time.h>


using namespace std;

int main()
{//tic-tac-toe game
	GameBoard Board;

	Player person;

	Player computer;
	
	char board[3][3];
	bool startGame;
	int currentRow;
	int currentCol;
	
	
	startGame = person.playersStep();

	
	srand(time(0));
	Board.clearingBoard(board);


	do
	{
		Board.showingBoard(board);

		if (startGame)
		{
			person.stepsOfPlayer(board, currentRow, currentCol);
		}
		else
		{
			computer.stepsOfComputer(board, currentRow, currentCol);
		}

		Board.updatingBoard(board, currentRow, currentCol, startGame);

		if (Board.checkWinning(board, startGame))
			break;

		if (Board.checkDraw(board))
		{
			Board.drawingBoard(true);
			break;
		}
		startGame = !startGame;
	} while (true);


	if (Board.getDraw())
		cout << "!DRAW!";
	else
	{
		if (startGame)
		{
			cout << "Congratulations, you won!!!!!!!!" << endl;
		}
		else
		{
			cout << "The computer won  :(" << endl;
		}
	}
	system("pause");
	return 0;
}
