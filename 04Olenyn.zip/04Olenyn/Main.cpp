#include <ostream>
#include <istream>
using namespace std;

#include "AComplex.h";
#include "TComplex.h";
#include <iostream>
int main()
{
	cout << "                                         Constructor 1     " << endl;
	cout << " A1  ";
	cout << endl;
	AComplex A1(2, 5);
	cout << " A2  ";
	cout << endl;
	AComplex A2(9, -4);
	cout << " T1  ";
	cout << endl;
	TComplex T1(20, 180);
	cout << " T2  ";
	cout << endl;
	TComplex T2(39, 79);




	cout << "                                          Constructor 2      " << endl;
	cout << " T3(T2)   ";
	TComplex T3(T2); cout << endl;
	cout << " A3(A2)   "; AComplex A3(A2); cout << endl;

	 
	cout << "                                         Constructor 3" << endl;
	cout << " A4(T1)   ";
	AComplex A4(T1); cout << endl;	cout << endl;  cout << " T4(A1)   "; cout << endl;
	TComplex T4(A1);
	cout  << endl;


	cout << "                          APPROPRIATION OF ACOMPLEX " << endl;
	cout <<  " A4=A3  " << (A4=A3) ; cout << endl;




	cout << "                        APPROPRIATION OF TCOMPLEX " << endl;
	cout << " T4=T3  " << (T4 = T3) << endl; cout << endl;


	
	cout << "                       GETTER/SETTER OF ACOMPLEX " << endl;
	cout <<"A1  "<< A1 ; cout << endl;
	cout << "real part: " << A1.re() << "  imaginary part: " << A1.im() << endl;
	(A1.re() = 12); (A1.im() = -10);
	cout << "A1 real part = 12  " << "  imaginary part= -10    " << endl<< "   result: "<< A1 ; cout << endl;
	cout << "modul: " << A1.mod() << "  argument: " << A1.arg() << endl;


	cout << "                        GETTER/SETTER OF TCOMPLEX " << endl;
	cout << "T1  " << T1; cout << endl;
	cout << "modul: " << T1.mod() << "  argument: " << T1.arg() << endl;
	cout << "modul=44 "  << "  argument=60 "  << endl;
	(T1.mod() = 44); (T1.arg() = 60);
	cout << T1 ; cout << endl;
	cout << "real part: " << T1.re() << "  imaginary part: " << T1.im() << endl;
	





	cout << "                        TEST ORERATIONS OF ACOMPLEX " << endl;
	
	cout << " (" << A1 << ") +  (" << A3 <<  ") = " << A1 + A3 << endl;
	cout << " (" << A1 << ") -  (" << A3 << ") = " << A1 - A3 << endl;

	cout << " (" << A1 << ") +=  (" << A3 << ") = " << endl;
	cout << (A1 += A3) << endl;
	cout << " (" << A1 << ") -=  (" << A3 << ") = "  << endl;
	cout << (A1 -= A3) << endl;
	cout << " (" << A1 << ") *=  (" << A3 << ") = "  << endl;
	cout << (A1 *= A3) << endl;
	cout << " (" << A1 << ") /=  (" << A3 << ") = " << endl;
	cout << (A1 /= A3) << endl;
	cout << " (" << A1 << ")^4  = " << power(A1,4) << endl;
	cout << " (" << A1 << ")^5  = " << power(A1, 5) << endl;
	cout << " (" << A1 << ") ==  (" << A2 << ") - " << (A1 == A2) << endl;
	cout << " (" << A1 << ") !=  (" << A2 << ") - " << (A1 != A2) << endl;







	cout << "                        TEST ORERATIONS OF TCOMPLEX " << endl;

		cout << " (" << T1 << ") *  (" << T3 << ") = " << T1 * T3 << endl;
	cout << " (" << T1 << ") /  (" << T3 << ") = " << T1 / T3 << endl;
	(T1 += T3);
	cout << " (" << T1 << ") +=  (" << T3 << ") = " << endl;
	cout << (T1 += T3) << endl;
	cout << " (" << T1 << ") -=  (" << T3 << ") = " << endl;
	cout << (T1 -= T3) << endl;
	cout << " (" << T1 << ") *=  (" << T3 << ") = "  << endl;
	cout << (T1 *= T3) << endl;
	cout << " (" << T1 << ") /=  (" << T3 << ") = "  << endl;
	cout << (T1 /= T3) << endl;
	cout << " (" << T1 << ")^4  = " << power(T1, 4) << endl;
	cout << " (" << T1 << ")^5  = " << power(T1, 5) << endl;
	cout << " (" << T1 << ") ==  (" << T2 << ") - " << (T1 == T2) << endl;
	cout << " (" << T1 << ") !=  (" << T2 << ") - " << (T1 != 2) << endl;





	cout << "                        TEST CIN OF ACOMPLEX " << endl;

	AComplex A5;
	cin >> A5;
	cout << "A5:  " << A5 << endl;
	cout << "                        TEST CIN OF TCOMPLEX " << endl;

	TComplex T5;
	cin >> T5;
	cout << "T5:  " << T5 << endl;
	system("pause");
	return 0;
}