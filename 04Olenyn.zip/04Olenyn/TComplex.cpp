#include <ostream>
#include <istream>
using namespace std;
#include "TComplex.h";
#include "AComplex.h";

#include <iostream>
int TComplex::_freeId( 0);
TComplex::TComplex(double ro , double phi ) : _ro(ro), _phi(phi), _id(++_freeId) {

#ifndef NDEBUG  
	cout  << " TComplex number was created  " << *this;
#endif
} 


TComplex::TComplex(const TComplex& a) : _ro(a.mod()), _phi(a.arg()), _id(++_freeId) {

#ifndef NDEBUG  
	cout  << " TComplex number was created  " << *this;
#endif
}

TComplex::TComplex(const AComplex& a) : _ro(a.mod()), _phi(a.arg()), _id(++_freeId) {

#ifndef NDEBUG  
	cout  << " TComplex number was created  " << *this;
#endif
}
TComplex::~TComplex() {

#ifndef NDEBUG  
	cout  << " TComplex number was deleted  " << *this;
#endif
}
TComplex& TComplex::operator= (const TComplex& a) {
	mod() = a.mod();
	arg() = a.arg();
	return *this;

}
TComplex& operator+=(TComplex& a, const TComplex& b) {
	
	 double r = a.re() + b.re();
	 double i = b.im() + a.im();
	a.mod() = sqrt(r * r + i * i);
	a.arg() = tanh(i / r);
	return a;

}
TComplex& operator-=(TComplex& a, const TComplex& b) {
	const double r = a.re() - b.re();
	const double i = b.im() - a.im();
	a.mod() = sqrt(r * r + i * i);
	a.arg() = tanh(i / r);
	return a;
}
TComplex& operator*=(TComplex& a, const TComplex& b) {
	a.mod() *= b.mod();
	a.arg() += b.arg();
	return a;
}
TComplex& operator/=(TComplex& a, const TComplex& b) {
	a.mod() /= b.mod();
	a.arg() -= b.arg();
	return a;
}

const TComplex  operator* (const TComplex& b, const TComplex& a) {
	return TComplex(b.mod() * a.mod(), b.arg() + a.arg());
}
const TComplex  operator/ (const TComplex& b, const TComplex& a) {
	return TComplex(b.mod() / a.mod(), b.arg() - a.arg());
}

const TComplex  power(const TComplex& a, unsigned int n) {
	return TComplex(pow(a.mod(), n), a.arg() * n);
}

ostream& operator<<(ostream& out, const TComplex& a)
{
	return out << " ID: " << a.getId() << "    " << a.mod() << "(cos(" << a.arg() << ") + sin(" << a.arg() << ")*i )" << endl;
}
istream& operator>>(istream& in, TComplex& a)
{
	cout << "Enter modul: ";
	cin >> a.mod();
	cout << endl;
	cout << "Enter argument: ";
	cin >> a.arg();
	cout << endl;
	return in;
}



