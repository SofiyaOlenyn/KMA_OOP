#include <ostream>
#include <istream>
using namespace std;

#include "AComplex.h";
#include "TComplex.h";
#include <iostream>
int AComplex::_freeId (0);
AComplex::AComplex(double re , double im ): _re(re),_im(im), _id(++_freeId){
#ifndef NDEBUG  
	cout << " AComplex number was created  " << *this;
#endif
}

AComplex::AComplex(const TComplex& a) :_re(a.re()), _im(a.im()), _id(++_freeId) {
#ifndef NDEBUG  
	cout <<   " AComplex number was created  " << *this;
#endif
}

AComplex::AComplex(const AComplex& a):_re(a.re()), _im(a.im()), _id(++_freeId) {
#ifndef NDEBUG  
	cout << " AComplex number was created  " << *this;
#endif
}

AComplex::~AComplex() {

#ifndef NDEBUG  
	cout <<  " AComplex number was deleted  " << *this;
#endif
}

AComplex& AComplex::operator= (const AComplex& a) {
	this->_re = a.re();
	this->_im = a.im();
	return *this;

}
AComplex& operator+=(AComplex& a, const AComplex& b) {
	a.re() += b.re();
    a.im() += b.im();
	return a;

}
AComplex& operator-=(AComplex& a, const AComplex& b) {
	a.re() -= b.re();
	a.im() -= b.im();
	return a;

}
AComplex& operator*=(AComplex& a, const AComplex& b) {
	
	a.re() *= (a.re() * b.re() - a.im() * b.im());
	a.im() *= (a.re() * b.im() + a.im() * b.re());
	return a;

}
AComplex& operator/=(AComplex& a, const AComplex& b) {
	a.re() = (a.re() * b.re() + a.im() * b.im()) / (pow(b.re(), 2) + pow(b.im(), 2));
	a.im() = (a.im() * b.re() - a.re() * b.re()) / (pow(b.re(), 2) + pow(b.im(), 2));
	return a;
}

const AComplex  operator+ (const AComplex& a, const AComplex& b) {
	return AComplex(a.re() + b.re(), a.im() + b.im());

}
const AComplex  operator- (const AComplex& a, const AComplex& b) {
	return AComplex(a.re() - b.re(), a.im() - b.im());
}
const AComplex  power(const AComplex& a, unsigned int n) {
	
	return AComplex((TComplex(pow(a.mod(), n), n * a.arg())));
}

bool operator== (const AComplex& a, const AComplex& b) 
{
	if ((a.re() == b.re()) && (a.im() == b.im())) {
		return true;
}
	return false;
}
bool operator!= (const AComplex& a, const AComplex& b) {
	return !(a == b);
}
ostream& operator<<(ostream& out, const AComplex& a)
{
	return out << " ID: " << a.getId() << "    " << a.re() << " + i*("<< a.im() << ") " << endl;
}
istream& operator>>(istream& in, AComplex& a)
{
	cout << "Enter real part: ";
	cin >> a.re();
	cout << endl;
	cout << "Enter iimaginary part.: ";
	cin >> a.im();
	cout << endl;
	return in;
}

