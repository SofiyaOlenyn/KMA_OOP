#include "Segment.h"
#include <iostream>
#include <math.h>
using namespace std;
int Segment::_freeID(0);
Segment::Segment(const double x1, const double y1 ,const double x2 , const double y2 ) :_myId(++_freeID),
  _a(x1, y1), _b(x2, y2) {

#ifndef NDEBUG 
	cout << _myId << ": a Segment was created: " << *this;
#endif

	return;
}
Segment::Segment(const Point& start, const Point& end) : _a(start), _b(end), _myId(++_freeID) {

#ifndef NDEBUG  
	cout << _myId << ": a Segment was created: " << *this;
#endif

	return;
}
Segment::Segment(const Segment& b) : _myId(++_freeID) {
	this->_a = b.start();
	this->_b = b.end();
#ifndef NDEBUG  
	cout << _myId << ": a Segment was created: " << *this;
#endif

}

Segment::~Segment() {

#ifndef NDEBUG  
	cout << _myId << ": a Segment was deleted: " << endl;
#endif

}

Segment& Segment::operator=(const Segment& b) {
	_a = b.start();
	_b = b.end();
	return *this;
}
const Point& Segment::start() const { return _a; }

const Point& Segment::end() const { return _b; }

Point& Segment::start() { return _a; };

Point& Segment::end() { return _b; };

const double& Segment::startX() const { return  _a.x(); };
const double& Segment::startY() const { return  _a.y(); };
const double& Segment::endX() const { return  _b.x(); };
const double& Segment::endY() const { return  _b.y(); };

double& Segment::startX() { return  _a.x(); };
double& Segment::startY() { return  _a.y(); };
double& Segment::endX() { return  _b.x(); };
double& Segment::endY() { return  _b.y(); };

double Segment::length() const {
	double res = sqrt((startX() - endX()) * (startX() - endX()) + (startY() - endY()) * (startY() - endY()));
	return res;
}



double Segment::distance(const Point& p) const {
	double a = this->length();
	double b = sqrt(((p.x() - startX()) * (p.x() - startX())) + ((p.y() - startY())* (p.y() - startY())));
	double c = sqrt(((p.x() - endX()) * (p.x() - endX())) + ((p.y() - endY()) * (p.y() - endY())));
	double P = (a + b + c)/2;
	double S = sqrt(P * (P - a) * (P - b) * (P - c));
	double res;
	if (a != 0) {
		 res = (2 * S) / a;
	}
	else res = sqrt(((p.x() - startX()) * (p.x() - startX())) + ((p.y() - startY()) * (p.y() - startY())));
	return res;
}

const int Segment::getID() const { return this->_myId; }

ostream& operator<<(ostream& out , const Segment& segment) {

	out << "(" << segment.startX() << "; " << segment.startY() << ") ------ (" << 
		segment.endX() << "; " << segment.endY() << ")" << endl;

	return out;
}
double distance(const Segment& s, const Point& p) {
	double a = sqrt((s.startX() - s.endX()) * (s.startX() - s.endX()) + (s.startY() - s.endY()) * (s.startY() - s.endY()));
	double b = sqrt(((p.x() - s.startX()) * (p.x() - s.startX())) + ((p.y() - s.startY()) * (p.y() - s.startY())));
	double c = sqrt(((p.x() - s.endX()) * (p.x() - s.endX())) + ((p.y() - s.endY()) * (p.y() - s.endY())));
	double P = (a + b + c) / 2;
	double S = sqrt(P * (P - a) * (P - b) * (P - c));
	double res;
	if (a != 0) {
		res = (2 * S) / a;
	}
	else res = sqrt(((p.x() - s.startX()) * (p.x() - s.startX())) + ((p.y() - s.startY()) * (p.y() - s.startY())));
	return res;

}