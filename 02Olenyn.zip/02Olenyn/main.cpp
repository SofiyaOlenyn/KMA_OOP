#include "Segment.h"
#include <iostream>
using namespace std;

int main()
{
	Segment s1;
	cout <<"lenght of segment  "<< s1.getID()<<" = " <<  s1.length()<<endl;
	Segment s2(2, -1, 4, 9);
	cout << "lenght of segment  " << s2.getID() << " = " << s2.length()<<endl;
	Point A(2, 3), B(5, 6);
	Segment s3(A, B);
	cout << "lenght of segment  " << s3.getID() << " = " << s3.length() << endl;
	Segment s4(s1);
	cout << "lenght of segment  " << s4.getID() << " = " << s4.length() << endl;
	cout << "Distance from segment " << s2.getID() << "  to point " << B <<" = " << s2.distance(B) << endl;
	cout << "Distance from segment " << s2.getID() << "  to point " << A << " = " << distance(s2,A) << endl;
	cout << "s2=s3" << endl;
	s2 = s3;
	cout << "Segment :" << s3.getID() << s3;
	cout << "Segment :" << s2.getID() << s2;
	cout << "Start  " << s2.start() << "      End " << s2.end() << endl;
	cout << "Start X = " << s2.startX() << "      Start Y = " << s2.startY() << endl;
	cout << "End X =  " << s2.endX() << "      End  Y = " << s2.endY() << endl;
	cout << "lenght of segment  " << s2.getID() << " = " << s2.length() << endl;

	system("pause");
	return 0;
}