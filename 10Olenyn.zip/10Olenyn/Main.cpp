
#include "Sequence.h"
#include <iostream>

using namespace std;
int main()
{
	try
	{
		cout << "----------------------TEST 1-----------------\n";
		cout << "----------------------Create Sequence<double>(3)------------------\n";
		const auto sequence = new Sequence<double>(3);
		cout << "---Before adding elements: \n" << *sequence << endl;
		cout << "Add new elements\n";
		(*sequence).add(6);
		(*sequence).add(71.1);
		(*sequence).add(-4);
	
		cout << "After adding new elements: " << *sequence << endl;
		
		(*sequence).remove(0);
		cout << "\n Remove first element:  " << *sequence << endl;
		cout << "\n Cheak if it is full: " << endl;
		cout << (*sequence).full();

		cout << (*sequence).clear();
	
		cout << "\n Cheak if it contains 6 : " << endl;
		cout << (*sequence).contains(6);
		
	}
catch ( Sequence<double>::BadSeq& bad)
{
	bad.diagnose();
}

	try{
	cout << "\n ----------------------TEST 2-----------------\n";
		const auto sequance = new Sequence<int>(5);
		cout << "Sequance before adding elements: " << *sequance;
		for (int i = 0; i < 10; ++i)
		{
			(*sequance).add(i*2+1);
		}

		cout << "Sequance after adding elements: " << *sequance << endl;

		(*sequance).remove(0);
		(*sequance).remove(0);
		

		cout << "Remove first 2 elements: " << *sequance << endl;

		cout << "insert(-4, 4): " << endl;
		(*sequance).insert(-4, 4);

		cout << *sequance << endl;

		cout << "Check if element -3 is in sequance: " << endl;

		cout << (*sequance).contains(-3) << endl;

		cout << "Check if sequance is full:" << endl;

		cout << (*sequance).full() << endl;

		cout << "Cut sequance: " << endl;
		(*sequance).cut();

		cout << *sequance << endl;

		(*sequance).clear();

		cout << "Clear sequance:" << endl;

		cout << *sequance << endl;



		
	}
	catch (Sequence<int>::BadSeq& bad)
	{
		bad.diagnose();
	}
	try {
		cout << "-----------------TEST 3-----------------\n";
		cout << "----cheak badseq--\n";
		const auto test = new Sequence<int>(3);
		
		(*test).add(1);
		(*test).add(2);
		(*test).add(3);
		cout << *test << endl;
		test[22];


	}
	catch (Sequence<int>::BadSeq& bad)
	{
		bad.diagnose();
	}
	system("pause");
	return 0;
}
