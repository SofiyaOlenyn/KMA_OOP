#pragma once
#include "Array.h"
#include <ostream>

template <class Elem>
class Sequence
{

public:
	class BadSeq {

	private:
		const string _reason;
		const size_t _index;
	public:
		explicit BadSeq(string r = "Unsigned exception", size_t i = 0) : _reason(std::move(r)), _index(i)
		{
		}
		~BadSeq() = default;

		void diagnose() const {
			cout << "BAD Sequence because of: " << _reason << " : " << _index << endl;
		}
	};
	explicit Sequence(const size_t capacity = _default);

	~Sequence()
	{};

	size_t capacity() const { return _capacity; }
	size_t size() const { return _size; }
	bool empty() const { return (size() == 0); }
	bool full() const { return (size() == capacity()); }

	Sequence& clear();
	const Elem& operator[](const size_t index) const;
	Elem& operator[](const size_t index);

	Sequence& add(const Elem&);
	Sequence& insert(const Elem&, const size_t index);
	Sequence& cut();
	Sequence& remove(const size_t index);

	bool contains(const Elem&);

	Sequence& operator=(const Sequence&) = delete;
	Sequence(const Sequence&) = delete;

	void start() const { _current = _start; }
	void next() const { ++_current; }
	bool stop() const { return (_current == _end); }
	const Elem& getCurrent() const { return *_current; }
private:
	size_t _size;
	size_t _capacity;
	static const size_t _default = 1;

	Array<Elem>* _allocator;

	Elem* _start;
	Elem* _end;
	mutable Elem* _current;

	void reduce(const size_t times = 2);
	void enlarge(const size_t times = 2);
	void update();

	Sequence& doinsert(const Elem&, const size_t);
	Sequence& doremove(const size_t);

};
template <class Elem>
const size_t Sequence<Elem>::_default = 100;
template <class Elem>
Sequence<Elem>::Sequence(const size_t cap) : _capacity(cap), _size(0),
_allocator(new Array<Elem>(cap)),
_start(&(*_allocator)[0]), _end(&(*_allocator)[capacity() - 1])
{
	return;
}
template <class Elem>
Sequence<Elem>& Sequence<Elem>::clear()
{
	delete _allocator;
	_capacity = 0;
	_size = 0;


	return *this;
}

template <class Elem>
const Elem& Sequence<Elem>::operator[](const size_t index) const
{
	if (empty()) { throw BadSeq("Try to manipulate the empty sequence"); }

	if (index > _size)
	{
		throw BadSeq("Try to access a non existing element of the sequence");
	}
	
	return _allocator[index]; 
	
}

template <class Elem>
Elem& Sequence<Elem>::operator[](const size_t index) {
	if(empty()) { throw BadSeq("Try to manipulate the empty sequence"); }

	if (index > _size)
	{
		throw BadSeq("Try to access a non existing element of the sequence");
	}

	return (*_allocator)[index];
}


template <class Elem>
Sequence<Elem>& Sequence<Elem>::add(const Elem& el)
{
	while (full())
	{
		enlarge();
	}

	(*_allocator)[size()] = el;
	++_size;
	update();

	return *this;
}

template <class Elem>
Sequence<Elem>& Sequence<Elem>::insert(const Elem& el, const size_t i)
{
	  if(_size<i) throw BadSeq( "Try to insert after a non existing element of the sequence"); 
	  return doinsert(el, i);
}
	

template <class Elem>
Sequence<Elem>& Sequence<Elem>::cut()
{
	doremove(size() - 1);
	update();

	return *this;
}

template <class Elem>
Sequence<Elem>& Sequence<Elem>::remove(const size_t i)
{
	doremove(i);
	update();

	return *this;
}



template <class Elem>
bool Sequence<Elem>::contains(const Elem& el)
{
	start();

	while (stop())
	{
		if (getCurrent() == el)
		{
			return true;
		}

		next();
	}

	return false;
}
template <class Elem>
void Sequence<Elem>::reduce(const size_t times)
{
	size_t capacity1 = (capacity() / 2);

	if (capacity1 <= 0)
	{
		capacity1 = _default;
	}

	Array<Elem>* array1 = new Array<Elem>(capacity1);

	for (size_t i = 0; i < size(); ++i)
	{
		(*array1)[i] = (*_allocator)[i];
	}

	delete _allocator;
	_allocator = new Array<Elem>(capacity1);

	for (size_t i = 0; i < size(); i++)
	{
		(*_allocator)[i] = (*array1)[i];
	}

	_capacity = capacity1;
}

template <class Elem>
void Sequence<Elem>::enlarge(const size_t t)
{
	size_t capacity1 = capacity() * t + capacity();
	Array<Elem>* array1 = new Array<Elem>(capacity1);

	for (size_t i = 0; i < size(); i++)
	{
		(*array1)[i] = (*_allocator)[i];
	}

	delete _allocator;
	_allocator = new Array<Elem>(capacity1);

	for (size_t i = 0; i < size(); i++)
	{
		(*_allocator)[i] = (*array1)[i];
	}

	_capacity = capacity1;
}

template <class Elem>
void Sequence<Elem>::update()
{
	_start = &(*_allocator)[0];

	if (size() == 0)
	{
		_end = _start;
	}
	else
	{
		_end = &(*_allocator)[size() - 1];
	}
}

template <class Elem>
Sequence<Elem>& Sequence<Elem>::doinsert(const Elem& elem, const size_t index)
{
	if (_size + 1 > capacity()) enlarge(); ++_size; 
	  
	for(size_t i=_size-1; i>index; i--)  
		(*_allocator)[i]=(*_allocator)[i-1]; 
	
	(*_allocator)[index]=elem;   
	return *this; } 

template <class Elem>
Sequence<Elem>& Sequence<Elem>::doremove(const size_t i)
{
	for (size_t k = i; k < size(); ++k)
	{
		(*this)[k] = (*this)[k + 1];
	}

	_size--;

	return *this;
}





template <class Elem>
std::ostream& operator<<(ostream& os, const Sequence<Elem>& s)
{
	if (s.empty())
	{
		os << "Sequence is empty" << endl;
	}
	else
	{
		int i = 0;
		s.start();

		while (!s.stop())
		{
			os << "Sequence[" << i++ << "] : " << s.getCurrent() << endl;
			s.next();
		}

		os << "Sequence[" << i << "] : " << s.getCurrent() << endl;
	}

	return os << "SIZE of sequence: " << s.size() << endl;
}
