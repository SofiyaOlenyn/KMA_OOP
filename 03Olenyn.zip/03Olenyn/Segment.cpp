#include <iostream>
#include <cmath>
#include "Triangle.h"
#include "Segment.h"
#include "Point.h"



int Triangle::Segment::_freeID (1);
int Segment::_freeID (1);

Triangle::Segment::Segment(const Point& start, const Point& end) : _a(start), _b(end), _myId(_freeID++)
{
#ifndef NDEBUG  
	cout << _myId << ": a Segment was created: " << *this;
#endif
}

Triangle::Segment::Segment(const Triangle::Segment& segment) : _a(segment._a), _b(segment._b), _myId(_freeID++)
{
#ifndef NDEBUG  
	cout << _myId << ": a Segment was created: " << *this;
#endif

}



Triangle::Segment::~Segment()
{
#ifndef NDEBUG  
	cout << _myId << ": a Segment was deleted: " << endl;
#endif
}




double Triangle::Segment::length() const
{
	double res = sqrt((_a.x() - _b.x()) * (_a.x() - _b.x()) + (_a.y() - _b.y()) * (_a.y() - _b.y()));
	return res;
}




double Triangle::Segment::distance(const Point& p) const
{
	double a = this->length();
	double b = sqrt(((p.x() - _a.x()) * (p.x() - _a.x())) + ((p.y() - _a.y()) * (p.y() - _a.y())));
	double c = sqrt(((p.x() - _b.x()) * (p.x() - _b.x())) + ((p.y() - _b.y()) * (p.y() - _b.y())));
	double P = (a + b + c) / 2;
	double S = sqrt(P * (P - a) * (P - b) * (P - c));
	double res;
	if (a != 0) {
		res = (2 * S) / a;
	}
	else res = sqrt(((p.x() - _a.x()) * (p.x() - _a.x())) + ((p.y() - _a.y()) * (p.y() - _a.y())));
	return res;
}

ostream& operator<<(ostream& out, const Segment& segment) {

	out << "(" << segment.start() << ") ------ (" <<
		segment.end() << ")" << endl;

	return out;
}
ostream& operator<<(ostream& out, const Triangle::Segment& segment)
{
	return out << "Segment ID: " << segment.getID() << "\n" << segment.start() << "\n" << segment.end() << "\nSegment length: " << segment.length() << endl;
}



