
#include <iostream>
#include <cmath>
#include "Triangle.h"
#include "Segment.h"



Triangle::Triangle(const double x1, const double y1,
	const double x2, const double y2,
	const double x3, const double y3) :_a(x1, y1), _b(x2, y2),
	_c(x3, y3), _ab(0), _bc(0), _ca(0)
{
#ifndef NDEBUG 
	cout << "Triangle was created: " << *this << endl;
#endif

	return;
}


Triangle::Triangle(const Point& a, const Point& b, const Point& c) :_a(a), _b(b), _c(c), _ab(0), _bc(0), _ca(0)
{
#ifndef NDEBUG 
	cout << "Triangle was created: " << *this << endl;
#endif
	return;
}



Triangle::Triangle(const Triangle& t) : _a(t._a), _b(t._b), _c(t._c),
_ab(0), _bc(0), _ca(0)
{


#ifndef NDEBUG 
	cout << "Triangle was created: " << *this << endl;
#endif
	return;
}


Triangle::Triangle(const Point& a, const ::Segment& _bc) : _a(a), _b(_bc.start()), _c(_bc.end()), _ab(0), _bc(0), _ca(0) {
#ifndef NDEBUG 
	cout << "Triangle was created: " << *this << endl;
#endif

}


Triangle::~Triangle() {
	delete _ab; delete _bc; delete _ca;
	_ab = _bc = _ca = 0;

#ifndef NDEBUG 
	cout << "Triangle was deleted" << endl;
#endif
}


Triangle& Triangle::operator= (const Triangle& t) {
	_a = t._a; _b = t._b; _c = t._c;
	delete _ab; delete _bc; delete _ca;
	_ab = _bc = _ca = 0;
	return *this;

}

double Triangle::perimeter() const {
	double res = (side_a().length()) + (side_b().length()) + (side_c().length());
	return res;
}

double Triangle::area() const {
	double P = (perimeter()) / 2;
	double S = sqrt(P * (P - length_a()) * (P - length_b()) * (P - length_c()));
	return S;

}

double Triangle::length_a() const
{
	return side_a().length();
}

double Triangle::length_b() const
{
	return side_b().length();
}

double Triangle::length_c() const
{
	return side_c().length();
}




const ::Segment& Triangle::median_a() const {
	Point S(((_b.x() + _c.x()) / 2), ((_b.y() + _c.y()) / 2));
	return *(new ::Segment(_a, S));
}

const ::Segment& Triangle::median_b() const {

	Point S(((_c.x() + _a.x()) / 2), ((_c.y() + _a.y()) / 2));

	return *(new ::Segment(_b, S));
}

const ::Segment& Triangle::median_c() const {
	Point S(((_b.x() + _a.x()) / 2), ((_b.y() + _a.y()) / 2));
	
	return *(new ::Segment(_c, S));

}



const Triangle::Segment& Triangle::side_a() const
{
	if (_bc == 0)
		_bc = new Triangle::Segment(_b, _c);
	return *_bc;
}

const Triangle::Segment& Triangle::side_b() const
{
	if (_ca == 0)
		_ca = new Triangle::Segment(_c, _a);
	return *_ca;
}

const Triangle::Segment& Triangle::side_c() const
{
	if (_ab == 0)
		_ab = new Triangle::Segment(_a, _b);
	return *_ab;
}





ostream& operator<<(ostream& out, const Triangle& t) {

	out << "( (" << t.apexA().x() << "; " << t.apexA().y() << ") ("
		<<
		t.apexB().x() << "; " << t.apexB().y() << ") (" << t.apexC().x() << "; " << t.apexC().y() << ") )";

	return out;
}


