#include "Point.h"
#include <iostream>

using namespace std;
int Point::freeID(0);


Point::Point(double x, double y) :_x(x), _y(y), pointID(++freeID)
{
#ifndef NDEBUG
	cout << "Point is created.  ID: " << this->pointID << " x = " << this->_x << " y = " << this->_y << endl;
#endif 

	return;
}

Point::Point(const Point& point) :pointID(++freeID) {

	this->_x = point._x;
	this->_y = point._y;

#ifndef NDEBUG
	cout << "Point is created.  ID: " << this->pointID << " x = " << this->_x << " y = " << this->_y << endl;
#endif 
	return;
}

Point::~Point() {
#ifndef NDEBUG 
	cout << "Point is deleted.   ID: " << this->pointID << endl;
#endif 

};

Point& Point::operator=(const Point& point) {
	_x = point._x;
	_y = point._y;
	return *this;
};

double& Point::x() { return _x; };

double& Point::y() { return _y; };

const double& Point::x()const { return _x; };

const double& Point::y()const { return _y; };

const int Point::getID()const { return this->pointID; };

int Point::amount() { return freeID; };

ostream& operator << (ostream& out, const Point& point)
{

	out << "(" << point.x() << "; " << point.y() << ")";

	return out;
}

const Point operator+ (const Point& u, const Point& v) {
	Point p;
	p.x() = v.x() + u.x();
	p.y() = v.x() + u.y();

	return p;
};

Point& operator+=(Point& a, const Point& b) {
	a = a + b;
	return a;
};

bool operator==(const Point& u, const Point& v) {
	if ((u.x() == v.x()) && (v.x() == v.x()))
	{
		return true;
	}
	else return false;
};


bool operator!=(const Point& u, const Point& v) {
	return !(u == v);
};
