#include "Array.h"
#include "Point.h"

using namespace std;

int main()
{
	{
		cout << "----------------------------------------- Test double-------------------------------" <<
			endl;
		try
		{
			cout << "--------Array<5, int> arr1--------" <<
				endl;
			Array<5, int> arr1;
			
			 (arr1[0]=1);
			 (arr1[1] = 4);
			(arr1[2] = -2);
			 (arr1[3] = 10);
		  (arr1[4] = 8);
		
		  for (int i = 0; i < (arr1.size()); i++)
		  {
			 
			  cout << "arr1[" << i << "] = " << arr1[i] << endl;
		  }
		  cout << "size() :" << arr1.size() << endl;
		  cout << "arr1[-1]" << endl;
		 arr1[-1];

		}

		catch (const Array<5, int>::BadArray& bad)
		{
			bad.diagnose();
		}
	}
	{
		cout << "----------------------------------------- Test char-------------------------------" <<
			endl;
		try
		{
			cout << "--------Array<5, char> arr2-------" <<
				endl;
			Array<5, char> arr2;

			(arr2[0] = 's');
			(arr2[1] = 'o');
			(arr2[2] = 'n');
			(arr2[3] = 'y');
			(arr2[4] = 'a');
			

			for (int i = 0; i < (arr2.size()); i++)
			{

				cout << "arr2[" << i << "] = " << arr2[i] << endl;
			}
			cout << "size() :" << arr2.size() << endl;
			cout << "arr2[6]" << endl;
			arr2[6];

		}

		catch (const Array<5, char>::BadArray& bad)
		{
			bad.diagnose();
		}
	}
	{
		cout << "----------------------------------------- Test Point-------------------------------" <<
			endl;
		try
		{
			cout << "--------Array<3, Point> arr3-------" <<
				endl;
			Array<3, Point> arr3;
			Point p1(1, 1), p2(-1, 5), p3(10, -1);
			(arr3[0] = p1);
			(arr3[1] = p2);
			(arr3[2] = p3);
			


			for (int i = 0; i < (arr3.size()); i++)
			{

				cout << "arr3[" << i << "] = " << arr3[i] << endl;
			}
			cout << "size() :" << arr3.size() << endl;
			cout << "arr3[10]" << endl;
			arr3[10];

		}

		catch (const Array<3, Point>::BadArray& bad)
		{
			bad.diagnose();
		}
	}
	
	system("pause");
	return 0;
}
