#pragma once
#include <string>
#include <iostream>

using namespace std;


template <size_t n, typename T>
class Array
{
private:
	size_t _size;
	T* _allocate;
	
	Array(const Array& other)=delete;
	Array& operator=(const Array& other)=delete;
public:
	explicit Array();
	~Array();

	size_t size() const;

	T& operator [](size_t);

	class BadArray {
	private:
		const string _reason;
		const size_t _index;
	public:
		explicit BadArray(string r = "=", size_t i = 0);
		~BadArray();

		void diagnose() const;
	};

};

template <size_t n, typename T>
Array<n, T>::BadArray::BadArray(string r, const size_t i) : _reason(std::move(r)), _index(i)
{
}


template <size_t n, typename T>
Array<n, T>::BadArray::~BadArray()
= default;



template <size_t n, typename T>
void Array<n, T>::BadArray::diagnose() const
{
	cerr <<"BAD ARRAY because of: " <<_reason << " : " << _index << endl;
}



template <size_t n, typename T>
Array<n, T>::Array() : _size(n), _allocate(new T[_size])
{
#ifndef NDEBUG
	cout << "Array created ->     size:" << n << ",  type: " << typeid(_allocate).name() << endl;
#endif
}

template <size_t n, typename T>
Array<n, T>::~Array()
{
	if (_allocate != nullptr)
	{
		delete[] _allocate;
		_allocate = nullptr;
	}

#ifndef NDEBUG
	cout << "Array deleted ->    size: " << n << ", type: " << typeid(_allocate).name() << endl;
#endif
}


template <size_t n, typename T>
T& Array<n, T>::operator[](size_t i)
{
	if (i < 0 || i >= _size)
	{
		throw BadArray("bad index", i);
	}

	return _allocate[i];
}

template <size_t n, typename T>
size_t Array<n, T>::size() const
{
	return _size;
}




